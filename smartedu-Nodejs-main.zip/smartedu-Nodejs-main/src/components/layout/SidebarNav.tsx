
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  MessageSquare,
  UserCircle,
  School,
  BookCopy,
  Users,
  ClipboardCheck,
  Code2,
  FileQuestion,
  Library,
  TrendingUp,
  Award,
  LogOut,
  Shield,
  FileText,
  Bell,
  Contact,
  CheckCircle,
  XCircle,
  Clock,
  BarChart,
  Settings,
  Book,
  Repeat,
  Database,
} from "lucide-react";

import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarHeader,
  SidebarGroupLabel,
  SidebarFooter,
  SidebarSeparator
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { getUserById } from "@/lib/mock-data";
import { Badge } from "../ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { useEffect } from "react";

const studentNavItems = [
  { href: "/dashboard", icon: LayoutDashboard, label: "لوحة التحكم" },
  { href: "/subjects", icon: Library, label: "المواد الدراسية" },
  { href: "/lessons", icon: BookCopy, label: "الدروس" },
  { href: "/dashboard/student/progress", icon: TrendingUp, label: "تقدمي" },
  { href: "/dashboard/student/results", icon: Award, label: "نتائجي" },
  { href: "/profile", icon: Settings, label: "الملف الشخصي" },
];

const teacherNavItems = [
  { href: "/dashboard/teacher", icon: LayoutDashboard, label: "لوحة التحكم" },
  { href: "/dashboard/teacher/lessons", icon: BookCopy, label: "إدارة الدروس" },
  { href: "/dashboard/teacher/exercises", icon: FileQuestion, label: "إدارة التمارين" },
  { href: "/dashboard/teacher/students", icon: Users, label: "تلاميذي" },
  { href: "/dashboard/teacher/submissions", icon: ClipboardCheck, label: "تصحيح التمارين" },
  { href: "/messages", icon: MessageSquare, label: "الرسائل" },
  { href: "/dashboard/teacher/my-code", icon: Code2, label: "كودي الخاص" },
  { href: "/profile", icon: Settings, label: "الإعدادات" },
]

const parentNavItems = [
  { href: "/dashboard/parent", icon: LayoutDashboard, label: "لوحة التحكم" },
  { href: "/dashboard/parent/children", icon: Users, label: "أبنائي" },
  { href: "/dashboard/parent/reports", icon: FileText, label: "التقارير" },
  { href: "/messages", icon: MessageSquare, label: "الرسائل" },
  { href: "/dashboard/parent/notifications", icon: Bell, label: "الإشعارات" },
  { href: "/profile", icon: Settings, label: "الملف الشخصي" },
];

const supervisorNavItems = [
  { href: "/dashboard/subject-supervisor", icon: LayoutDashboard, label: "لوحة التحكم" },
  { href: "/dashboard/subject-supervisor/lessons", icon: Book, label: "إدارة الدروس"},
  { href: "/dashboard/subject-supervisor/exercises", icon: FileQuestion, label: "إدارة التمارين"},
  { href: "/dashboard/subject-supervisor/statistics", icon: BarChart, label: "الإحصائيات" },
  { href: "/messages", icon: MessageSquare, label: "الرسائل" },
  { href: "/profile", icon: Settings, label: "الإعدادات" },
];

const directeurNavItems = [
    { href: "/dashboard/directeur", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/dashboard/directeur/users", icon: Users, label: "إدارة المستخدمين" },
    { href: "/dashboard/directeur/content", icon: BookCopy, label: "إدارة المحتوى" },
    { href: "/messages", icon: MessageSquare, label: "الرسائل" },
    { href: "/dashboard/directeur/database", icon: Database, label: "قاعدة البيانات" },
    { href: "/dashboard/directeur/settings", icon: Settings, label: "الإعدادات" },
];


const getNavItems = (role?: string, pathname?: string) => {
  if (pathname?.startsWith('/dashboard/teacher')) {
      return teacherNavItems;
  }
  switch (role) {
    case 'directeur':
        return directeurNavItems;
    case 'teacher':
      return teacherNavItems;
    case 'student':
      return studentNavItems;
    case 'parent':
      return parentNavItems;
    case 'supervisor_specific':
      return supervisorNavItems;
    default:
      return studentNavItems; // Default to student
  }
}

const getCurrentUser = (pathname: string) => {
    if (pathname.startsWith('/dashboard/directeur')) {
        return getUserById(3); // directeur
    }
    if (pathname.startsWith('/dashboard/subject-supervisor')) {
        return getUserById(7); // supervisor
    }
    if (pathname.startsWith('/dashboard/teacher')) {
        const rolePath = sessionStorage.getItem('currentRolePath');
        // If we are navigating within the teacher dashboard but the "true" role is supervisor
        if (rolePath?.startsWith('/dashboard/subject-supervisor')) {
            return getUserById(7); // supervisor acting as teacher
        }
        return getUserById(2); // teacher
    }
    if (pathname.startsWith('/dashboard/parent')) {
        return getUserById(4); // parent
    }
    // Default to student for other main pages like /lessons, /profile, /messages etc.
    // unless a role context is already stored
    const rolePath = sessionStorage.getItem('currentRolePath');
    if (rolePath) {
        if (rolePath.startsWith('/dashboard/directeur')) return getUserById(3);
        if (rolePath.startsWith('/dashboard/subject-supervisor')) return getUserById(7);
        if (rolePath.startsWith('/dashboard/teacher')) return getUserById(2);
        if (rolePath.startsWith('/dashboard/parent')) return getUserById(4);
    }
    
    return getUserById(1); // student
}

export function SidebarNav() {
  const pathname = usePathname();
  
  useEffect(() => {
    // This is a hack for the prototype to persist the "context"
    // of which dashboard the user is in.
    if (pathname.startsWith('/dashboard/directeur')) {
        sessionStorage.setItem('currentRolePath', '/dashboard/directeur');
    } else if (pathname.startsWith('/dashboard/subject-supervisor')) {
        sessionStorage.setItem('currentRolePath', '/dashboard/subject-supervisor');
    } else if (pathname.startsWith('/dashboard/teacher')) {
        // Don't overwrite if the origin is supervisor
        const currentRole = sessionStorage.getItem('currentRolePath');
        if (!currentRole || !currentRole.startsWith('/dashboard/subject-supervisor')) {
            sessionStorage.setItem('currentRolePath', '/dashboard/teacher');
        }
    } else if (pathname.startsWith('/dashboard/parent')) {
        sessionStorage.setItem('currentRolePath', '/dashboard/parent');
    } else if (pathname.startsWith('/dashboard/student') || pathname === '/dashboard') {
         sessionStorage.setItem('currentRolePath', '/dashboard/student');
    }
  }, [pathname]);

  const user = getCurrentUser(pathname);
  const navItems = getNavItems(user?.role, pathname);

  const getIsActive = (href: string) => {
    // Special handling for dashboards
    if (href.endsWith('dashboard')) {
        const dashboardPaths = ['/dashboard', '/dashboard/student', '/dashboard/teacher', '/dashboard/parent', '/dashboard/subject-supervisor', '/dashboard/directeur'];
        const isDashboard = dashboardPaths.some(p => pathname.startsWith(p) && p.length >= pathname.length)
        if (isDashboard) return true;
    }
    
    // For nested routes, check if the pathname starts with the href
    if (href !== '/' && href.length > 1) {
      return pathname.startsWith(href);
    }
    
    return pathname === href;
  }

  if (!user) {
    return null;
  }
  
  const roleName = (user: any) => {
    if (user.role === 'supervisor_specific' && pathname.startsWith('/dashboard/teacher')) {
        return 'معلم (مشرف)';
    }
    return {
        directeur: 'مدير',
        teacher: 'معلم',
        student: 'طالب',
        parent: 'ولي أمر',
        supervisor_specific: 'مشرف مادة'
    }[user.role] || 'مستخدم';
  }


  return (
    <>
      <div className="flex-1 overflow-y-auto p-2">
          <SidebarHeader className="border-b border-sidebar-border">
            <div className="flex items-center gap-2">
              <School className="h-8 w-8 text-sidebar-primary-foreground" />
              <div className="flex flex-col">
                <h2 className="text-lg font-semibold text-sidebar-primary-foreground">
                  SmartEdu
                </h2>
                <Badge variant="secondary" className="w-fit">{roleName(user)}</Badge>
              </div>
            </div>
          </SidebarHeader>

          <SidebarMenu>
              <SidebarGroupLabel>القائمة الرئيسية</SidebarGroupLabel>
              {navItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                  <Link href={item.href} passHref>
                    <SidebarMenuButton
                        asChild
                        isActive={getIsActive(item.href)}
                        className="justify-start"
                    >
                      <div>
                        <item.icon className="ml-2 h-5 w-5" />
                        <span>{item.label}</span>
                      </div>
                    </SidebarMenuButton>
                  </Link>
              </SidebarMenuItem>
              ))}

              {user.role === 'supervisor_specific' && (
                <>
                    <SidebarSeparator />
                     <SidebarMenuItem>
                        {pathname.startsWith('/dashboard/teacher') ? (
                             <Link href="/dashboard/subject-supervisor" passHref>
                                <SidebarMenuButton className="justify-start">
                                    <div>
                                        <Repeat className="ml-2 h-5 w-5" />
                                        <span>العودة لواجهة المشرف</span>
                                    </div>
                                </SidebarMenuButton>
                            </Link>
                        ) : (
                             <Link href="/dashboard/teacher" passHref>
                                <SidebarMenuButton className="justify-start">
                                    <div>
                                        <Repeat className="ml-2 h-5 w-5" />
                                        <span>التبديل لواجهة المعلم</span>
                                    </div>
                                </SidebarMenuButton>
                            </Link>
                        )}
                    </SidebarMenuItem>
                </>
              )}
          </SidebarMenu>
      </div>
      
      <SidebarFooter className="border-t border-sidebar-border p-2 space-y-2">
          <div className="p-2 flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.prenom.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex flex-col truncate">
                  <span className="font-semibold text-sidebar-primary-foreground text-sm">{user.name}</span>
                  <span className="text-xs text-sidebar-foreground/70 truncate">{user.email}</span>
              </div>
          </div>
          <SidebarMenuItem>
              <Link href="/login" passHref>
                <SidebarMenuButton className="justify-start">
                    <div>
                        <LogOut className="ml-2 h-5 w-5" />
                        <span>تسجيل الخروج</span>
                    </div>
                </SidebarMenuButton>
              </Link>
          </SidebarMenuItem>
      </SidebarFooter>
    </>
  );
}
