
import type { User, Lesson, Exercise, Subject, Level, Stage, Message, Submission } from './types';
import { PlaceHolderImages } from './placeholder-images';

const getImageUrl = (id: string) => PlaceHolderImages.find(img => img.id === id)?.imageUrl || '';

export const USERS: User[] = [
  {
    id: 1,
    nom: 'Al-Ghamdi',
    prenom: 'Fatima',
    name: 'Fatima Al-Ghamdi',
    email: 'fatima.student@example.com',
    role: 'student',
    level_id: 1,
    student_code: 'S12345',
    avatar: getImageUrl('avatar1'),
    ai_evaluation_mode: 'auto',
    connected_teacher_code: 'T9876',
    parent_id: 4
  },
  {
    id: 2,
    nom: 'Mahmoud',
    prenom: 'Ahmed',
    name: 'Ahmed Mahmoud',
    email: 'ahmed.teacher@example.com',
    role: 'teacher',
    subject_id: 1,
    teacher_code: 'T9876',
    avatar: getImageUrl('avatar2'),
    ai_evaluation_mode: 'manual'
  },
  {
    id: 3,
    nom: 'Khan',
    prenom: 'Aisha',
    name: 'Aisha Khan',
    email: 'aisha.director@example.com',
    role: 'directeur',
    avatar: getImageUrl('avatar3'),
    ai_evaluation_mode: 'manual'
  },
  {
    id: 4,
    nom: 'Al-Ghamdi',
    prenom: 'Khalid',
    name: 'Khalid Al-Ghamdi',
    email: 'khalid.parent@example.com',
    role: 'parent',
    parent_code: 'P54321',
    avatar: getImageUrl('avatar4'),
    ai_evaluation_mode: 'manual'
  },
  {
    id: 5,
    nom: 'Al-Ghamdi',
    prenom: 'Omar',
    name: 'Omar Al-Ghamdi',
    email: 'omar.student@example.com',
    role: 'student',
    level_id: 3,
    student_code: 'S67890',
    avatar: getImageUrl('avatar5'),
    ai_evaluation_mode: 'auto',
    connected_teacher_code: 'T-SUPER-01',
    parent_id: 4
  },
  {
    id: 6,
    nom: 'Hassan',
    prenom: 'Noura',
    name: 'Noura Hassan',
    email: 'noura.teacher@example.com',
    role: 'teacher',
    subject_id: 2,
    teacher_code: 'T1122',
    avatar: getImageUrl('avatar6'),
    ai_evaluation_mode: 'manual'
  },
  {
    id: 7,
    nom: 'Al-Farsi',
    prenom: 'Youssef',
    name: 'Youssef Al-Farsi',
    email: 'youssef.supervisor@example.com',
    role: 'supervisor_specific',
    subject_id: 1,
    teacher_code: 'T-SUPER-01',
    avatar: getImageUrl('avatar7'),
    ai_evaluation_mode: 'manual'
  }
];

export const STAGES: Stage[] = [
    { id: 1, name: 'مرحلة التعليم الإبتدائي', order: 1 },
    { id: 2, name: 'مرحلة التعليم المتوسط', order: 2 },
    { id: 3, name: 'مرحلة التعليم الثانوي', order: 3 },
];

export const LEVELS: Level[] = [
    { id: 1, name: 'الصف الأول الابتدائي', stage_id: 1, order: 1 },
    { id: 2, name: 'الصف الثاني الابتدائي', stage_id: 1, order: 2 },
    { id: 3, name: 'أولى متوسط', stage_id: 2, order: 1 },
    { id: 4, name: 'ثانية متوسط', stage_id: 2, order: 2 },
    { id: 5, name: 'ثالثة متوسط', stage_id: 2, order: 3 },
    { id: 6, name: 'رابعة متوسط', stage_id: 2, order: 4 },
];

export const SUBJECTS: Subject[] = [
  { id: 1, name: 'الرياضيات', description: 'مادة الرياضيات للمرحلة الابتدائية', level_id: 1, stage_id: 1 },
  { id: 2, name: 'اللغة العربية', description: 'مادة اللغة العربية للمرحلة الابتدائية', level_id: 1, stage_id: 1 },
  { id: 3, name: 'العلوم', description: 'مادة العلوم للمرحلة الابتدائية', level_id: 1, stage_id: 1 },
  { id: 4, name: 'الرياضيات', description: 'مادة الرياضيات للمرحلة المتوسطة', stage_id: 2 },
  { id: 5, name: 'اللغة العربية', description: 'مادة اللغة العربية للمرحلة المتوسطة', stage_id: 2 },
  { id: 6, name: 'العلوم الطبيعية', description: 'مادة العلوم الطبيعية للمرحلة المتوسطة', stage_id: 2 },
  { id: 7, name: 'اللغة الفرنسية', description: 'مادة اللغة الفرنسية للمرحلة المتوسطة', stage_id: 2 },
];

export const LESSONS: Lesson[] = [
  {
    id: 1,
    title: 'مقدمة في الجمع (خاص)',
    content: '<p>في هذا الدرس، سنتعلم أساسيات عملية الجمع. الجمع هو عملية دمج مجموعتين من الأشياء في مجموعة واحدة. سنتعرف على رمز الجمع (+) وكيفية استخدامه لحل المسائل البسيطة.</p>',
    video_url: 'https://www.youtube.com/watch?v=Fe9iI42pXpI',
    subject_id: 1,
    level_id: 1,
    author_id: 2, // Teacher Ahmed
    type: 'private',
    is_locked: false,
  },
  {
    id: 2,
    title: 'الحروف الهجائية (عام)',
    content: '<p>درس ممتع لاستكشاف الحروف الهجائية العربية. سنتعلم نطق كل حرف وشكله في بداية الكلمة ومنتصفها ونهايتها، مع أمثلة ورسومات توضيحية.</p>',
    video_url: 'https://www.youtube.com/watch?v=Fe9iI42pXpI',
    subject_id: 2,
    level_id: 1,
    author_id: 7, // Supervisor Youssef
    type: 'public',
    is_locked: false,
  },
  {
    id: 3,
    title: 'أجزاء النبات (عام)',
    content: '<p>سنتعرف على الأجزاء الرئيسية للنبات ووظيفة كل جزء، من الجذور التي تمتص الماء، إلى الساق والأوراق والأزهار. رحلة ممتعة في عالم النباتات.</p>',
    video_url: 'https://www.youtube.com/watch?v=Fe9iI42pXpI',
    subject_id: 3,
    level_id: 1,
    author_id: 7, // Supervisor Youssef
    type: 'public',
    is_locked: true,
  },
   {
    id: 4,
    title: 'مفهوم الطرح (خاص)',
    content: '<p>في هذا الدرس، سنتعلم أساسيات عملية الطرح وكيفية استخدامها في حياتنا اليومية.</p>',
    video_url: 'https://www.youtube.com/watch?v=some_video',
    subject_id: 1,
    level_id: 1,
    author_id: 2, // Teacher Ahmed
    type: 'private',
    is_locked: false,
  },
  {
    id: 5,
    title: 'الأعداد النسبية (خاص بالمشرف)',
    content: '<p>درس خاص من المشرف Youssef لطلابه حول الأعداد النسبية.</p>',
    video_url: 'https://www.youtube.com/watch?v=some_video',
    subject_id: 1,
    level_id: 1,
    author_id: 7, // Supervisor Youssef
    type: 'private',
    is_locked: false,
  },
];

export const EXERCISES: Exercise[] = [
  {
    id: 1,
    lesson_id: 1,
    question: 'إذا كان لديك 3 تفاحات وأعطاك صديقك تفاحتين، كم عدد التفاحات التي لديك الآن؟',
    model_answer: '3 + 2 = 5 تفاحات. لديك الآن 5 تفاحات.',
    order: 1,
  },
  {
    id: 2,
    lesson_id: 1,
    question: 'اجمع 4 + 5.',
    model_answer: '4 + 5 = 9',
    order: 2,
  },
    {
    id: 3,
    lesson_id: 4,
    question: 'اجمع 7 + 3.',
    model_answer: '7 + 3 = 10',
    order: 1,
  },
  {
    id: 4,
    lesson_id: 2,
    question: 'اكتب الحرف التالي لحرف "ب" في الهجاء.',
    model_answer: 'الحرف التالي هو "ت".',
    order: 1,
  },
  {
    id: 5,
    lesson_id: 5,
    question: '',
    question_file_url: '/exercises/exercise_5.pdf',
    model_answer: '3/2',
    order: 1,
  },
  {
    id: 6,
    lesson_id: 3,
    question: 'ما هو الجزء الذي يثبت النبات في التربة؟',
    model_answer: 'الجذور.',
    order: 1,
  },
];

export const SUBMISSIONS: Submission[] = [
    {
        id: 1,
        student_id: 1,
        exercise_id: 1,
        answer: "لدي 5 تفاحات.",
        attempt_number: 1,
        ai_feedback: "إجابة صحيحة وممتازة! لقد فهمت السؤال جيداً وقمت بعملية الجمع بشكل صحيح.",
        score: 10,
        submitted_at: "2024-05-21T10:00:00Z",
        status: "graded",
    },
    {
        id: 2,
        student_id: 1,
        exercise_id: 2,
        answer: "الناتج هو 9.",
        attempt_number: 1,
        ai_feedback: "أحسنت! إجابة صحيحة.",
        score: 9,
        submitted_at: "2024-05-22T11:30:00Z",
        status: "pending",
    },
    {
        id: 3,
        student_id: 1,
        exercise_id: 4,
        answer: "الحرف هو تاء",
        attempt_number: 1,
        ai_feedback: "إجابة رائعة! استمر في التقدم.",
        score: 9,
        submitted_at: "2024-05-23T09:00:00Z",
        status: "pending",
    },
     {
        id: 4,
        student_id: 5,
        exercise_id: 1,
        answer: "8",
        attempt_number: 2,
        ai_feedback: "هناك خطأ بسيط في الحساب. حاول مرة أخرى!",
        score: 4,
        submitted_at: "2024-05-24T14:00:00Z",
        status: "graded",
    },
    {
        id: 5,
        student_id: 1,
        exercise_id: 5,
        answer: "الجواب في الملف المرفق",
        submission_file_url: "/submissions/submission_5.pdf",
        attempt_number: 1,
        ai_feedback: "تم إرفاق الملف بنجاح، سيقوم الأستاذ بمراجعته.",
        score: 7,
        submitted_at: "2024-05-25T11:00:00Z",
        status: "pending",
    }
];

export const MESSAGES: Message[] = [
    {
        id: 1,
        subject: "استفسار بخصوص واجب الرياضيات",
        sender_name: "Fatima Al-Ghamdi",
        author_id: 1,
        content: "مرحباً أستاذ أحمد، لدي سؤال حول التمرين الثاني في درس الجمع. هل يمكنك توضيح المطلوب؟ شكراً لك.",
        recipient_id: 2,
        is_read: false,
        created_at: "2024-05-20T10:00:00Z"
    },
    {
        id: 2,
        subject: "Re: استفسار بخصوص واجب الرياضيات",
        sender_name: "Ahmed Mahmoud",
        author_id: 2,
        content: "أهلاً فاطمة، المطلوب في التمرين الثاني هو إيجاد ناتج جمع الرقمين. بالتوفيق.",
        recipient_id: 1,
        is_read: true,
        created_at: "2024-05-20T10:30:00Z"
    },
    {
        id: 3,
        subject: "خطة تطوير المناهج",
        sender_name: "Aisha Khan",
        author_id: 3,
        content: "مرحباً أستاذ أحمد، أود مناقشة مقترحاتك لتطوير منهج العلوم للصف الأول. هل أنت متاح لاجتماع غداً؟",
        recipient_id: 2,
        is_read: true,
        created_at: "2024-05-19T15:00:00Z"
    },
    {
        id: 4,
        subject: "متابعة أداء فاطمة",
        sender_name: "Khalid Al-Ghamdi",
        author_id: 4,
        content: "مرحباً أستاذ أحمد، أود الاستفسار عن مستوى ابنتي فاطمة في مادة الرياضيات. كيف هو أداؤها بشكل عام؟",
        recipient_id: 2,
        is_read: false,
        created_at: "2024-05-24T12:00:00Z"
    },
    {
        id: 5,
        subject: "Re: متابعة أداء فاطمة",
        sender_name: "Ahmed Mahmoud",
        author_id: 2,
        content: "أهلاً بك أستاذ خالد. فاطمة طالبة ممتازة ومستواها في تقدم مستمر. أداؤها في التمارين الأخيرة كان رائعًا. لا تتردد في التواصل معي لأي استفسار.",
        recipient_id: 4,
        is_read: true,
        created_at: "2024-05-24T12:30:00Z"
    },
    {
        id: 6,
        subject: "بخصوص درس الأعداد النسبية",
        sender_name: "Omar Al-Ghamdi",
        author_id: 5,
        content: "مرحباً أستاذ يوسف، شكراً على الدرس المفيد. هل يمكن أن تعطينا المزيد من التمارين؟",
        recipient_id: 7,
        is_read: false,
        created_at: "2024-05-25T14:00:00Z"
    },
    {
        id: 7,
        subject: "Re: بخصوص درس الأعداد النسبية",
        sender_name: "Youssef Al-Farsi",
        author_id: 7,
        content: "أهلاً عمر، بالتأكيد. سأقوم بإضافة تمارين جديدة قريباً. استمر في العمل الجيد!",
        recipient_id: 5,
        is_read: true,
        created_at: "2024-05-25T14:30:00Z"
    }
];

// API-like functions
export const getParent = (id: number) => USERS.find(u => u.id === id && u.role === 'parent');
export const getChildrenOfParent = (parentId: number) => USERS.filter(u => u.role === 'student' && u.parent_id === parentId);
export const getStudent = (id: number) => USERS.find(u => u.id === id && u.role === 'student');
export const getTeacher = (id: number) => USERS.find(u => u.id === id && u.role === 'teacher');
export const getSubjectSupervisor = (id: number) => USERS.find(u => u.id === id && u.role === 'supervisor_specific');
export const getLessons = () => LESSONS;
export const getLessonById = (id: number) => LESSONS.find(l => l.id === id);
export const getExercisesForLesson = (lessonId: number) => EXERCISES.filter(e => e.lesson_id === lessonId).sort((a, b) => a.order - b.order);
export const getExerciseById = (id: number) => EXERCISES.find(e => e.id === id);
export const getUserById = (id: number) => USERS.find(u => u.id === id);
export const getSubjectById = (id: number) => SUBJECTS.find(s => s.id === id);
export const getSubjects = () => SUBJECTS;
export const getMessagesForUser = (userId: number) => MESSAGES.filter(m => m.recipient_id === userId || m.author_id === userId).sort((a,b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
export const getSubmissionsForStudent = (studentId: number) => SUBMISSIONS.filter(s => s.student_id === studentId);
export const getSubmissionsForStudents = (studentIds: number[]) => SUBMISSIONS.filter(s => studentIds.includes(s.student_id));
export const getSubmissionById = (submissionId: number) => SUBMISSIONS.find(s => s.id === submissionId);
export const getSubmissionsForTeacher = (teacherId: number) => {
    const teacher = getUserById(teacherId);
    if (!teacher || !teacher.teacher_code) return [];

    const teacherStudents = USERS.filter(u => u.role === 'student' && u.connected_teacher_code === teacher.teacher_code);
    const studentIds = teacherStudents.map(s => s.id);
    
    return SUBMISSIONS.filter(s => studentIds.includes(s.student_id));
}
    








    



