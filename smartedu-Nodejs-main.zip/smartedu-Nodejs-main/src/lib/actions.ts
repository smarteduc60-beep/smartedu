"use server";

import { z } from "zod";
import { getAiFeedback } from "@/ai/flows/ai-submission-feedback";
import { getExerciseById, getStudent } from "@/lib/mock-data";

export type SubmissionState = {
  feedback?: string;
  score?: number;
  suggestedPrompts?: string[];
  error?: string;
};

const submissionSchema = z.object({
  answer: z.string(),
  exerciseId: z.string(),
  submissionFile: z.instanceof(File).optional(),
});

export async function handleSubmission(
  prevState: SubmissionState,
  formData: FormData
): Promise<SubmissionState> {
  try {
    const parsed = submissionSchema.safeParse({
      answer: formData.get("answer"),
      exerciseId: formData.get("exerciseId"),
      submissionFile: formData.get("submissionFile"),
    });

    if (!parsed.success) {
      return { error: "البيانات المدخلة غير صالحة." };
    }

    const { answer, exerciseId, submissionFile } = parsed.data;

    if (!answer && (!submissionFile || submissionFile.size === 0)) {
        return { error: "يجب عليك كتابة إجابة أو إرفاق ملف." };
    }


    const exercise = getExerciseById(parseInt(exerciseId, 10));
    const student = getStudent(1); // Mock: Assume student with ID 1 is logged in

    if (!exercise || !student) {
      return { error: "لم يتم العثور على التمرين أو الطالب." };
    }

    let fileDataUri: string | undefined = undefined;
    if (submissionFile && submissionFile.size > 0) {
        const fileBuffer = Buffer.from(await submissionFile.arrayBuffer());
        fileDataUri = `data:${submissionFile.type};base64,${fileBuffer.toString("base64")}`;
    }

    const feedbackResponse = await getAiFeedback({
      studentId: student.id,
      exerciseId: exercise.id,
      answer: answer,
      modelAnswer: exercise.model_answer,
      studentProfile: `المستوى: ${student.level_id}, نمط التقييم: ${student.ai_evaluation_mode}`,
      submissionFile: fileDataUri
    });

    if (!feedbackResponse) {
      return { error: "حدث خطأ أثناء الحصول على تقييم الذكاء الاصطناعي." };
    }

    return {
      feedback: feedbackResponse.feedback,
      score: feedbackResponse.score,
      suggestedPrompts: feedbackResponse.suggestedPrompts,
    };
  } catch (e) {
    console.error(e);
    return { error: "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى." };
  }
}
