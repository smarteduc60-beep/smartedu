import { config } from 'dotenv';
config();

import '@/ai/flows/ai-submission-feedback.ts';
import '@/ai/flows/probabilistic-feedback-prompt-selection.ts';