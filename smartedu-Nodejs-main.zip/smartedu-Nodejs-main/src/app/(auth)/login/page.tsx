
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { School } from "lucide-react";
import Link from "next/link";

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary">
            <School className="h-10 w-10 text-primary-foreground" />
          </div>
          <CardTitle className="text-3xl">أهلاً بك في SmartEdu</CardTitle>
          <CardDescription>
            منصتك الذكية للتعلم. سجل الدخول للمتابعة.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                placeholder="email@example.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input id="password" type="password" required />
            </div>
            <Link href="/dashboard" passHref>
                <Button type="submit" className="w-full">
                    تسجيل الدخول
                </Button>
            </Link>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-4">
            <div className="relative w-full">
                <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">
                        أو استمر باستخدام
                    </span>
                </div>
            </div>
            <Button variant="outline" className="w-full">
                تسجيل الدخول باستخدام Google
            </Button>
            <div className="mt-4 text-center text-sm">
                ليس لديك حساب؟{" "}
                <Link href="/signup" className="underline">
                    إنشاء حساب
                </Link>
            </div>
        </CardFooter>
      </Card>
    </div>
  );
}
