
'use client';

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { School } from "lucide-react";
import Link from "next/link";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { STAGES, LEVELS, SUBJECTS } from "@/lib/mock-data";
import type { UserRole } from "@/lib/types";
import { Input } from "@/components/ui/input";

export default function CompleteProfilePage() {
  const [role, setRole] = useState<UserRole | ''>('');
  const [stage, setStage] = useState<string>('');

  const handleRoleChange = (value: string) => {
    setRole(value as UserRole);
    setStage(''); // Reset stage when role changes
  };

  const levelsForStage = LEVELS.filter(level => String(level.stage_id) === stage);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-lg shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary">
            <School className="h-10 w-10 text-primary-foreground" />
          </div>
          <CardTitle className="text-3xl">أكمل ملفك الشخصي</CardTitle>
          <CardDescription>
            خطوة أخيرة! الرجاء اختيار دورك واستكمال بياناتك.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            {/* User's name and email would typically be pre-filled from Google */}
             <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="first-name">الاسم الأول</Label>
                <Input id="first-name" defaultValue="Ahmad" disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="last-name">الاسم الأخير</Label>
                <Input id="last-name" defaultValue="Mahmoud" disabled />
              </div>
            </div>
             <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                defaultValue="ahmad.mahmoud@google.com"
                disabled
              />
            </div>
            
            <div className="space-y-4">
              <Label htmlFor="role">الدور</Label>
              <Select onValueChange={handleRoleChange} value={role}>
                <SelectTrigger id="role">
                  <SelectValue placeholder="اختر دورك" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="teacher">أستاذ</SelectItem>
                  <SelectItem value="student">طالب</SelectItem>
                  <SelectItem value="parent">ولي أمر</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {role === 'teacher' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="teacher-stage">المرحلة</Label>
                  <Select>
                    <SelectTrigger id="teacher-stage"><SelectValue placeholder="اختر المرحلة" /></SelectTrigger>
                    <SelectContent>
                      {STAGES.map(stage => <SelectItem key={stage.id} value={String(stage.id)}>{stage.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="teacher-subject">المادة</Label>
                  <Select>
                    <SelectTrigger id="teacher-subject"><SelectValue placeholder="اختر المادة" /></SelectTrigger>
                    <SelectContent>
                      {SUBJECTS.map(subject => <SelectItem key={subject.id} value={String(subject.id)}>{subject.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {role === 'student' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="student-stage">المرحلة</Label>
                  <Select onValueChange={setStage} value={stage}>
                    <SelectTrigger id="student-stage"><SelectValue placeholder="اختر المرحلة" /></SelectTrigger>
                    <SelectContent>
                      {STAGES.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-level">المستوى الدراسي</Label>
                  <Select disabled={!stage}>
                    <SelectTrigger id="student-level"><SelectValue placeholder="اختر المستوى" /></SelectTrigger>
                    <SelectContent>
                      {levelsForStage.map(level => <SelectItem key={level.id} value={String(level.id)}>{level.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <Link href="/dashboard" passHref>
              <Button type="submit" className="w-full !mt-8">
                حفظ والمتابعة
              </Button>
            </Link>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

