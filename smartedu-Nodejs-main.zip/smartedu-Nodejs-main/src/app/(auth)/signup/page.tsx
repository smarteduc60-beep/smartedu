
'use client';

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { School } from "lucide-react";
import Link from "next/link";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { STAGES, LEVELS, SUBJECTS } from "@/lib/mock-data";
import type { UserRole } from "@/lib/types";

export default function SignupPage() {
  const [role, setRole] = useState<UserRole | ''>('');
  const [stage, setStage] = useState<string>('');

  const handleRoleChange = (value: string) => {
    setRole(value as UserRole);
    setStage(''); // Reset stage when role changes
  };

  const levelsForStage = LEVELS.filter(level => String(level.stage_id) === stage);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-lg shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary">
            <School className="h-10 w-10 text-primary-foreground" />
          </div>
          <CardTitle className="text-3xl">إنشاء حساب جديد</CardTitle>
          <CardDescription>
            انضم إلى SmartEdu وابدأ رحلتك التعليمية.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="first-name">الاسم الأول</Label>
                <Input id="first-name" placeholder="مثال: أحمد" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="last-name">الاسم الأخير</Label>
                <Input id="last-name" placeholder="مثال: المحمود" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                placeholder="email@example.com"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="role">الدور</Label>
              <Select onValueChange={handleRoleChange} value={role}>
                <SelectTrigger id="role">
                  <SelectValue placeholder="اختر دورك" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="teacher">أستاذ</SelectItem>
                  <SelectItem value="student">طالب</SelectItem>
                  <SelectItem value="parent">ولي أمر</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {role === 'teacher' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="teacher-stage">المرحلة</Label>
                  <Select>
                    <SelectTrigger id="teacher-stage"><SelectValue placeholder="اختر المرحلة" /></SelectTrigger>
                    <SelectContent>
                      {STAGES.map(stage => <SelectItem key={stage.id} value={String(stage.id)}>{stage.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="teacher-subject">المادة</Label>
                  <Select>
                    <SelectTrigger id="teacher-subject"><SelectValue placeholder="اختر المادة" /></SelectTrigger>
                    <SelectContent>
                      {SUBJECTS.map(subject => <SelectItem key={subject.id} value={String(subject.id)}>{subject.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {role === 'student' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="student-stage">المرحلة</Label>
                  <Select onValueChange={setStage} value={stage}>
                    <SelectTrigger id="student-stage"><SelectValue placeholder="اختر المرحلة" /></SelectTrigger>
                    <SelectContent>
                      {STAGES.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-level">المستوى الدراسي</Label>
                  <Select disabled={!stage}>
                    <SelectTrigger id="student-level"><SelectValue placeholder="اختر المستوى" /></SelectTrigger>
                    <SelectContent>
                      {levelsForStage.map(level => <SelectItem key={level.id} value={String(level.id)}>{level.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input id="password" type="password" required />
            </div>

            <Link href="/dashboard" passHref>
              <Button type="submit" className="w-full !mt-6">
                إنشاء حساب
              </Button>
            </Link>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-4">
          <div className="relative w-full">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">
                أو استمر باستخدام
              </span>
            </div>
          </div>
          <Link href="/complete-profile" className="w-full">
            <Button variant="outline" className="w-full">
                إنشاء حساب باستخدام Google
            </Button>
          </Link>
          <div className="mt-4 text-center text-sm">
            لديك حساب بالفعل؟{" "}
            <Link href="/login" className="underline">
              تسجيل الدخول
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
