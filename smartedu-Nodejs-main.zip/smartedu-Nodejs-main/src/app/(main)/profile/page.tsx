
'use client';

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getUserById, getSubjectById, getParent, getTeacher } from "@/lib/mock-data";
import { useToast } from "@/hooks/use-toast";
import { Save, Link as LinkIcon, UserMinus, Users, Copy, UserCheck } from "lucide-react";
import type { User } from "@/lib/types";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";

const getCurrentUserByPath = (pathname: string | null) => {
    if (!pathname) return getUserById(1); // Default to student

    if (pathname.startsWith('/dashboard/subject-supervisor')) return getUserById(7);
    if (pathname.startsWith('/dashboard/teacher')) return getUserById(2);
    if (pathname.startsWith('/dashboard/parent')) return getUserById(4);
    
    return getUserById(1); // Default to student
}


const StudentProfile = ({ user }: { user: User }) => {
  const teacher = user.connected_teacher_code ? getTeacher(2) : null; // Assuming teacher is ID 2 for demo
  const teacherSubject = teacher && teacher.subject_id ? getSubjectById(teacher.subject_id) : null;
  const parent = user.parent_id ? getParent(user.parent_id) : null;

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>المعلومات الشخصية</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <Button variant="outline">تغيير الصورة</Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="prenom">الاسم الأول</Label>
              <Input id="prenom" defaultValue={user.prenom} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="nom">الاسم الأخير</Label>
              <Input id="nom" defaultValue={user.nom} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <Input id="email" type="email" defaultValue={user.email} />
          </div>
          <div className="flex justify-end">
            <Button>
              <Save className="ml-2 h-4 w-4" />
              <span>حفظ التغييرات</span>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <LinkIcon className="text-primary" />
                <span>الربط بحساب المعلم</span>
            </CardTitle>
            <CardDescription>
                أدخل كود المعلم لربط حسابك ومشاركة تقدمك معه.
            </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="flex items-center gap-2">
                <Input id="teacher-code" placeholder="أدخل كود المعلم هنا..." />
                <Button>ربط الحساب</Button>
                </div>
                
                <div className="space-y-4">
                    <Label className="flex items-center gap-2 text-muted-foreground">
                        <Users className="h-5 w-5" />
                        <span>المعلمون المرتبطون</span>
                    </Label>
                    {teacher && (
                        <div className="flex items-center justify-between rounded-lg border p-3 bg-muted/50">
                            <div>
                                <span className="font-semibold">{teacher.name}</span>
                                {teacherSubject && <span className="text-sm text-muted-foreground mx-2">({teacherSubject.name})</span>}
                            </div>
                            <Button variant="destructive" size="sm">
                                <UserMinus className="ml-2 h-4 w-4" />
                                <span>إلغاء الربط</span>
                            </Button>
                        </div>
                    )}
                    {!teacher && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            أنت غير مرتبط بأي معلم حاليًا.
                        </p>
                    )}
                </div>
            </CardContent>
        </Card>

         <Card>
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <UserCheck className="text-primary" />
                <span>الربط بولي الأمر</span>
            </CardTitle>
            <CardDescription>
                أدخل كود ولي الأمر ليتمكن من متابعة تقدمك.
            </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="flex items-center gap-2">
                <Input id="parent-code" placeholder="أدخل كود ولي الأمر هنا..." />
                <Button>ربط الحساب</Button>
                </div>
                
                <div className="space-y-4">
                     <Label className="flex items-center gap-2 text-muted-foreground">
                        <Users className="h-5 w-5" />
                        <span>ولي الأمر المرتبط</span>
                    </Label>
                    {parent && (
                        <div className="flex items-center justify-between rounded-lg border p-3 bg-muted/50">
                            <div className="flex items-center gap-3">
                                <Avatar className="h-8 w-8">
                                    <AvatarImage src={parent.avatar} alt={parent.name} />
                                    <AvatarFallback>{parent.prenom.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <span className="font-semibold">{parent.name}</span>
                            </div>
                             <Button variant="destructive" size="sm">
                                <UserMinus className="ml-2 h-4 w-4" />
                                <span>إلغاء الربط</span>
                            </Button>
                        </div>
                    )}
                     {!parent && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                            أنت غير مرتبط بولي أمر حاليًا.
                        </p>
                    )}
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

const TeacherProfile = ({ user }: { user: User }) => (
    <Card>
        <CardHeader>
          <CardTitle>تفاصيل الحساب</CardTitle>
          <CardDescription>
            قم بإدارة معلوماتك الشخصية وتفضيلات الحساب.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-20 w-20">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <Button variant="outline">تغيير الصورة</Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                <Label htmlFor="prenom">الاسم الأول</Label>
                <Input id="prenom" defaultValue={user.prenom} />
                </div>
                <div className="space-y-2">
                <Label htmlFor="nom">الاسم الأخير</Label>
                <Input id="nom" defaultValue={user.nom} />
                </div>
            </div>
            <div className="space-y-2">
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input id="email" type="email" defaultValue={user.email} />
            </div>
            <div className="flex justify-end">
              <Button>
                <Save className="mr-2 h-4 w-4" />
                <span>حفظ التغييرات</span>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
  );

const ParentProfile = ({ user }: { user: User }) => {
    const { toast } = useToast();

    const handleCopy = () => {
        if (user.parent_code) {
            navigator.clipboard.writeText(user.parent_code);
            toast({
                title: "تم النسخ!",
                description: "تم نسخ كود الربط إلى الحافظة.",
            });
        }
    };

    return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>المعلومات الشخصية</CardTitle>
          <CardDescription>قم بتحديث معلومات حسابك.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <Button variant="outline">تغيير الصورة</Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="prenom">الاسم الأول</Label>
              <Input id="prenom" defaultValue={user.prenom} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="nom">الاسم الأخير</Label>
              <Input id="nom" defaultValue={user.nom} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <Input id="email" type="email" defaultValue={user.email} />
          </div>
          <div className="flex justify-end">
            <Button>
              <Save className="ml-2 h-4 w-4" />
              <span>حفظ التغييرات</span>
            </Button>
          </div>
        </CardContent>
      </Card>
       <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LinkIcon className="text-primary" />
            <span>كود ربط الأبناء</span>
          </CardTitle>
          <CardDescription>
            شارك هذا الكود مع أبنائك لربط حساباتهم بحسابك.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
                <Input readOnly defaultValue={user.parent_code} className="text-lg font-mono tracking-widest text-center" />
                <Button variant="outline" size="icon" aria-label="نسخ الكود" onClick={handleCopy}>
                    <Copy className="h-5 w-5" />
                </Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}

const SupervisorProfile = ({ user }: { user: User }) => {
    return (
        <Card>
            <CardHeader>
              <CardTitle>تفاصيل الحساب</CardTitle>
              <CardDescription>
                قم بإدارة معلوماتك الشخصية كـ "{user.role === 'supervisor_specific' ? 'مشرف مادة' : 'مشرف عام'}".
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <Button variant="outline">تغيير الصورة</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                    <Label htmlFor="prenom">الاسم الأول</Label>
                    <Input id="prenom" defaultValue={user.prenom} />
                    </div>
                    <div className="space-y-2">
                    <Label htmlFor="nom">الاسم الأخير</Label>
                    <Input id="nom" defaultValue={user.nom} />
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <Input id="email" type="email" defaultValue={user.email} />
                </div>
                <div className="flex justify-end">
                  <Button>
                    <Save className="ml-2 h-4 w-4" />
                    <span>حفظ التغييرات</span>
                  </Button>
                </div>
              </form>
            </CardContent>
        </Card>
    )
}

export default function ProfilePage() {
  const pathname = usePathname();
  const [currentUser, setCurrentUser] = useState<User | null | undefined>(null);

  useEffect(() => {
    const rolePath = sessionStorage.getItem('currentRolePath') || pathname;
    setCurrentUser(getCurrentUserByPath(rolePath));
  }, [pathname]);

  if (!currentUser) {
    return <div>Loading...</div>;
  }
  
  const ProfileComponent = () => {
    if (!currentUser) return null;

    if (currentUser.role === 'student') return <StudentProfile user={currentUser} />;
    if (currentUser.role === 'parent') return <ParentProfile user={currentUser} />;
    if (currentUser.role === 'teacher') return <TeacherProfile user={currentUser} />;
    if (currentUser.role === 'supervisor_specific') {
        // The sessionStorage trick will let us know if we are in the "teacher" context
        const rolePath = sessionStorage.getItem('currentRolePath');
        if (rolePath?.startsWith('/dashboard/teacher')) {
            return <TeacherProfile user={currentUser} />;
        }
        return <SupervisorProfile user={currentUser} />;
    }
    return <p>لا يوجد ملف شخصي متاح لهذا الدور.</p>;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold tracking-tight mb-8">
        الملف الشخصي والإعدادات
      </h1>
      <ProfileComponent />
    </div>
  );
}

    