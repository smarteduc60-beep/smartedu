
'use client';

import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getLessons, getSubjects, getUserById, USERS } from "@/lib/mock-data";
import { Users, BookCopy, BarChart3, Database, Settings } from "lucide-react";
import Link from "next/link";

export default function DirecteurDashboard({ directeurId }: { directeurId: number }) {
    const directeur = getUserById(directeurId);
    if (!directeur) return <div>لم يتم العثور على حساب المدير.</div>;

    const allUsers = USERS;
    const teachers = allUsers.filter(u => u.role === 'teacher' || u.role === 'supervisor_specific');
    const students = allUsers.filter(u => u.role === 'student');
    const lessons = getLessons();
    const subjects = getSubjects();

    return (
        <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">
                        أهلاً بك، {directeur?.name}!
                    </h1>
                    <p className="text-muted-foreground">
                        نظرة عامة على أداء المنصة التعليمية.
                    </p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{allUsers.length}</div>
                        <p className="text-xs text-muted-foreground">جميع الأدوار</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">المعلمون والمشرفون</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{teachers.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي الطاقم التعليمي</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">الطلاب</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{students.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي الطلاب المسجلين</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">الدروس</CardTitle>
                        <BookCopy className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{lessons.length}</div>
                         <p className="text-xs text-muted-foreground">إجمالي الدروس المنشأة</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">المواد الدراسية</CardTitle>
                        <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{subjects.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي المواد المتاحة</p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid gap-6">
                 <Card>
                    <CardHeader>
                        <CardTitle>روابط سريعة</CardTitle>
                        <CardDescription>وصول سريع لأقسام الإدارة الرئيسية.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/users"><Users className="ml-2"/>إدارة المستخدمين</Link>
                        </Button>
                        <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/content"><BookCopy className="ml-2"/>إدارة المحتوى</Link>
                        </Button>
                        <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/database"><Database className="ml-2"/>قاعدة البيانات</Link>
                        </Button>
                         <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/settings"><Settings className="ml-2"/>الإعدادات</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
