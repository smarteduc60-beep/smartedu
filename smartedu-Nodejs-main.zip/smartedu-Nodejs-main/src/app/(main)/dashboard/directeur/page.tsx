
import DirecteurDashboard from "../_components/DirecteurDashboard";

export default function DirecteurDashboardPage() {
    // We assume director ID is 3 for now
    return <DirecteurDashboard directeurId={3} />
}
