
'use client';

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { USERS, LESSONS, SUBJECTS, EXERCISES, SUBMISSIONS, STAGES, LEVELS, MESSAGES } from "@/lib/mock-data";
import { Database, Search, Download } from "lucide-react";

type TableName = 'users' | 'lessons' | 'subjects' | 'exercises' | 'submissions' | 'stages' | 'levels' | 'messages';

const MOCK_DB: Record<TableName, any[]> = {
    users: USERS,
    lessons: LESSONS,
    subjects: SUBJECTS,
    exercises: EXERCISES,
    submissions: SUBMISSIONS,
    stages: STAGES,
    levels: LEVELS,
    messages: MESSAGES,
};

const tableTranslations: Record<TableName, string> = {
    users: 'المستخدمون',
    lessons: 'الدروس',
    subjects: 'المواد',
    exercises: 'التمارين',
    submissions: 'الإجابات',
    stages: 'المراحل',
    levels: 'المستويات',
    messages: 'الرسائل',
};

export default function DatabasePage() {
    const [selectedTable, setSelectedTable] = useState<TableName>('users');
    const [searchTerm, setSearchTerm] = useState('');

    const tableData = MOCK_DB[selectedTable] || [];
    
    const filteredData = tableData.filter(row => {
        if (!searchTerm) return true;
        return Object.values(row).some(value => 
            String(value).toLowerCase().includes(searchTerm.toLowerCase())
        );
    });

    const headers = tableData.length > 0 ? Object.keys(tableData[0]) : [];

    const renderCell = (value: any) => {
        if (typeof value === 'boolean') {
            return value ? 'نعم' : 'لا';
        }
        if (typeof value === 'object' && value !== null) {
            return JSON.stringify(value);
        }
        const strValue = String(value);
        return strValue.length > 50 ? `${strValue.substring(0, 50)}...` : strValue;
    };

    return (
        <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">فحص قاعدة البيانات</h1>
                    <p className="text-muted-foreground">
                        عرض مباشر لجداول البيانات في المنصة.
                    </p>
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>مستعرض الجداول</CardTitle>
                    <CardDescription>اختر جدولاً لعرض محتوياته.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-1">
                            <Select 
                                value={selectedTable} 
                                onValueChange={(value) => setSelectedTable(value as TableName)}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="اختر جدول" />
                                </SelectTrigger>
                                <SelectContent>
                                    {Object.keys(MOCK_DB).map(tableName => (
                                        <SelectItem key={tableName} value={tableName}>
                                            {tableTranslations[tableName as TableName]} ({MOCK_DB[tableName as TableName].length})
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="md:col-span-2 flex gap-2">
                             <div className="relative w-full">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input 
                                    placeholder={`ابحث في جدول ${tableTranslations[selectedTable]}...`}
                                    className="pl-10" 
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                            <Button variant="outline">
                                <Download className="ml-2 h-4 w-4" />
                                <span>تصدير CSV</span>
                            </Button>
                        </div>
                    </div>

                    <p className="text-sm text-muted-foreground">
                        عرض {filteredData.length} من أصل {tableData.length} سجل في جدول "{tableTranslations[selectedTable]}".
                    </p>
                    
                    <div className="border rounded-md">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    {headers.map(header => (
                                        <TableHead key={header}>{header}</TableHead>
                                    ))}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredData.length > 0 ? (
                                    filteredData.slice(0, 100).map((row, rowIndex) => ( // Limit to 100 rows for performance
                                        <TableRow key={rowIndex}>
                                            {headers.map(header => (
                                                <TableCell key={`${rowIndex}-${header}`} className="font-mono text-xs max-w-xs truncate">
                                                    {renderCell(row[header])}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={headers.length} className="h-24 text-center">
                                            لا توجد بيانات لعرضها.
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                    {filteredData.length > 100 && (
                        <p className="text-sm text-muted-foreground text-center">
                            يتم عرض أول 100 سجل فقط. استخدم البحث لتصفية النتائج.
                        </p>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
