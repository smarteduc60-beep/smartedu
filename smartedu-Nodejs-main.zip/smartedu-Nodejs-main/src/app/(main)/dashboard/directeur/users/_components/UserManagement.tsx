
'use client';

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Users,
  Search,
  PlusCircle,
  FilePenLine,
  Trash2,
} from "lucide-react";
import { USERS } from "@/lib/mock-data";
import type { User, UserRole } from "@/lib/types";

const roleTranslation: Record<UserRole, string> = {
    directeur: 'مدير',
    supervisor_general: 'مشرف عام',
    supervisor_specific: 'مشرف مادة',
    teacher: 'معلم',
    student: 'طالب',
    parent: 'ولي أمر',
};

const roleVariant: Record<UserRole, "default" | "secondary" | "destructive" | "outline"> = {
    directeur: 'destructive',
    supervisor_general: 'secondary',
    supervisor_specific: 'secondary',
    teacher: 'outline',
    student: 'default',
    parent: 'default',
};

export default function UserManagement() {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<UserRole | "all">("all");

  const students = USERS.filter((u) => u.role === "student").length;
  const teachers = USERS.filter((u) => u.role === "teacher" || u.role === 'supervisor_specific').length;
  const parents = USERS.filter((u) => u.role === "parent").length;

  const filteredUsers = USERS.filter((user) => {
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    const matchesSearch =
      user.name.toLowerCase().includes(search.toLowerCase()) ||
      user.email.toLowerCase().includes(search.toLowerCase());
    return matchesRole && matchesSearch;
  });

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <div className="grid gap-1">
          <h1 className="text-3xl font-bold tracking-tight">إدارة المستخدمين</h1>
          <p className="text-muted-foreground">
            عرض وتعديل والبحث عن المستخدمين في المنصة.
          </p>
        </div>
         <Button>
            <PlusCircle className="ml-2 h-4 w-4" />
            <span>إضافة مستخدم جديد</span>
        </Button>
      </div>

       <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{USERS.length}</div>
            <p className="text-xs text-muted-foreground">جميع الأدوار</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الطلاب</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{students}</div>
            <p className="text-xs text-muted-foreground">إجمالي الطلاب المسجلين</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الطاقم التعليمي</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teachers}</div>
            <p className="text-xs text-muted-foreground">معلمون ومشرفون</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">أولياء الأمور</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{parents}</div>
            <p className="text-xs text-muted-foreground">إجمالي أولياء الأمور</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة المستخدمين</CardTitle>
          <CardDescription>
            تم العثور على {filteredUsers.length} مستخدم.
          </CardDescription>
        </CardHeader>
        <CardContent>
            <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
                <div className="relative w-full sm:max-w-xs">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="ابحث بالاسم أو البريد..." 
                        className="pl-10" 
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
                <div className="flex gap-2 flex-wrap">
                    <Button variant={roleFilter === 'all' ? 'default' : 'outline'} onClick={() => setRoleFilter('all')}>الكل</Button>
                    <Button variant={roleFilter === 'student' ? 'default' : 'outline'} onClick={() => setRoleFilter('student')}>طالب</Button>
                    <Button variant={roleFilter === 'teacher' ? 'default' : 'outline'} onClick={() => setRoleFilter('teacher')}>معلم</Button>
                    <Button variant={roleFilter === 'supervisor_specific' ? 'default' : 'outline'} onClick={() => setRoleFilter('supervisor_specific')}>مشرف</Button>
                    <Button variant={roleFilter === 'parent' ? 'default' : 'outline'} onClick={() => setRoleFilter('parent')}>ولي أمر</Button>
                    <Button variant={roleFilter === 'directeur' ? 'default' : 'outline'} onClick={() => setRoleFilter('directeur')}>مدير</Button>
                </div>
            </div>

           <Table>
            <TableHeader>
              <TableRow>
                <TableHead>المستخدم</TableHead>
                <TableHead>الدور</TableHead>
                <TableHead>البريد الإلكتروني</TableHead>
                <TableHead className="text-center">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                        <TableCell>
                            <div className="flex items-center gap-3">
                                <Avatar>
                                    <AvatarImage src={user.avatar} alt={user.name} />
                                    <AvatarFallback>{user.prenom.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <span className="font-medium">{user.name}</span>
                            </div>
                        </TableCell>
                        <TableCell>
                           <Badge variant={roleVariant[user.role]}>{roleTranslation[user.role]}</Badge>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell className="text-center">
                            <div className="flex justify-center gap-2">
                                <Button variant="ghost" size="icon" title="تعديل">
                                    <FilePenLine className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" title="حذف" className="text-destructive hover:text-destructive">
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        </TableCell>
                    </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center h-24">
                    لم يتم العثور على مستخدمين.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
