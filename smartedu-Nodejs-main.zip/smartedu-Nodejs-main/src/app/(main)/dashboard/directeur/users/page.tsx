
import UserManagement from "./_components/UserManagement";

export default function UserManagementPage() {
  return <UserManagement />;
}
