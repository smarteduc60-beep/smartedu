
'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { notFound, useRouter } from "next/navigation";
import { TrendingUp, Target, BookCheck, ArrowLeft, MessageSquare } from "lucide-react";
import Link from "next/link";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts";
import { getLessons, getUserById, getSubmissionsForStudent, getExerciseById, getExercisesForLesson, getSubjects, getLessonById, USERS } from "@/lib/mock-data";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function ChildDetailsPage({ params }: { params: { id: string } }) {
  const child = getUserById(Number(params.id));

  if (!child || child.role !== 'student') {
    notFound();
  }
  
  const teacher = child.connected_teacher_code ? USERS.find(u => u.role === 'teacher' && u.teacher_code === child.connected_teacher_code) : null;
  const submissions = getSubmissionsForStudent(child.id);
  const allLessons = getLessons();
  const allSubjects = getSubjects();

  // Calculate statistics
  const solvedExercisesCount = submissions.length;
  
  const completedLessonsSet = new Set<number>();
  allLessons.forEach(lesson => {
    const lessonExercises = getExercisesForLesson(lesson.id);
    if (lessonExercises.length > 0) {
      const allSolved = lessonExercises.every(ex => 
        submissions.some(sub => sub.exercise_id === ex.id && (sub.score ?? 0) >= 6)
      );
      if (allSolved) {
        completedLessonsSet.add(lesson.id);
      }
    }
  });
  const completedLessonsCount = completedLessonsSet.size;

  const totalScore = submissions.reduce((acc, s) => acc + (s.score ?? 0), 0);
  const totalPossibleScore = submissions.length * 10;
  const averageScore = totalPossibleScore > 0 ? Math.round((totalScore / totalPossibleScore) * 100) : 0;

  // Calculate progress per subject
  const subjectsProgress = allSubjects.map((subject, index) => {
    const subjectLessons = allLessons.filter(l => l.subject_id === subject.id);
    const subjectExerciseIds = subjectLessons.flatMap(l => getExercisesForLesson(l.id).map(e => e.id));
    
    const subjectSubmissions = submissions.filter(sub => subjectExerciseIds.includes(sub.exercise_id));

    if (subjectSubmissions.length === 0) {
      return { subject: subject.name, score: 0, color: `hsl(var(--chart-${(index % 5) + 1}))` };
    }

    const subjectTotalScore = subjectSubmissions.reduce((acc, s) => acc + (s.score ?? 0), 0);
    const subjectPossibleScore = subjectSubmissions.length * 10;
    const subjectAverage = Math.round((subjectTotalScore / subjectPossibleScore) * 100);

    return { subject: subject.name, score: subjectAverage, color: `hsl(var(--chart-${(index % 5) + 1}))` };
  });

  const getScoreVariant = (score: number) => {
    if (score >= 8) return 'default';
    if (score >= 5) return 'secondary';
    return 'destructive';
  }

  const recentSubmissions = submissions.sort((a,b) => new Date(b.submitted_at).getTime() - new Date(a.submitted_at).getTime()).slice(0, 5);


  return (
    <div className="flex flex-col gap-8">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20">
                    <AvatarImage src={child.avatar} alt={child.name} />
                    <AvatarFallback>{child.prenom.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">تقرير أداء {child.prenom}</h1>
                    <p className="text-muted-foreground">
                        نظرة شاملة على تقدم {child.prenom} الدراسي.
                    </p>
                </div>
            </div>
             <Link href="/dashboard/parent/children" passHref>
                <Button variant="outline">
                    <ArrowLeft className="h-4 w-4" />
                    <span className="mr-2">الرجوع إلى قائمة الأبناء</span>
                </Button>
            </Link>
        </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">الدروس المكتملة</CardTitle>
            <BookCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedLessonsCount}</div>
            <p className="text-xs text-muted-foreground">من إجمالي {allLessons.length} دروس</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">التمارين المحلولة</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{solvedExercisesCount}</div>
            <p className="text-xs text-muted-foreground">إجمالي التمارين التي تم حلها</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">متوسط الدرجات</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageScore}%</div>
            <p className="text-xs text-muted-foreground">في جميع التمارين</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>الأداء حسب المادة</CardTitle>
            <CardDescription>
              متوسط درجات {child.prenom} في المواد المختلفة.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={subjectsProgress} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                 <XAxis
                  dataKey="subject"
                  tickLine={false}
                  axisLine={false}
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickFormatter={(value) => `${value}%`}
                />
                 <Tooltip
                    cursor={{ fill: 'hsl(var(--accent) / 0.2)' }}
                    content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                            return (
                            <div className="rounded-lg border bg-background p-2 shadow-sm">
                                <div className="grid grid-cols-2 gap-2">
                                <div className="flex flex-col">
                                    <span className="text-muted-foreground text-sm">
                                    {payload[0].payload.subject}
                                    </span>
                                    <span className="font-bold text-lg">
                                    {payload[0].value}%
                                    </span>
                                </div>
                                </div>
                            </div>
                            )
                        }
                        return null
                        }}
                 />
                <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                    {subjectsProgress.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        <div className="lg:col-span-2">
            <Card>
                <CardHeader>
                    <CardTitle>التواصل مع المعلم</CardTitle>
                    <CardDescription>
                        تواصل مع معلمي {child.prenom} لمتابعة تقدمه.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     {teacher ? (
                        <div className="flex items-center justify-between rounded-lg border p-4 bg-muted/50">
                            <div className="flex items-center gap-3">
                                <Avatar>
                                    <AvatarImage src={teacher.avatar} alt={teacher.name} />
                                    <AvatarFallback>{teacher.prenom.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="font-semibold">{teacher.name}</p>
                                    <p className="text-sm text-muted-foreground">معلم المادة</p>
                                </div>
                            </div>
                            <Link href={`/messages?recipient=${teacher.id}`} passHref>
                                <Button size="sm">
                                    <MessageSquare className="ml-2 h-4 w-4" />
                                    <span>مراسلة</span>
                                </Button>
                            </Link>
                        </div>
                    ) : (
                        <p className="text-muted-foreground text-center py-4">
                            هذا الطالب غير مرتبط بأي معلم حاليًا.
                        </p>
                    )}
                </CardContent>
            </Card>
        </div>
      </div>

       <Card>
        <CardHeader>
            <CardTitle>آخر الإجابات</CardTitle>
            <CardDescription>
                آخر التمارين التي قام {child.prenom} بحلها.
            </CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>التمرين</TableHead>
                        <TableHead>الدرجة</TableHead>
                        <TableHead className="hidden md:table-cell">التقييم</TableHead>
                        <TableHead className="text-left">التاريخ</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                {recentSubmissions.length > 0 ? (
                    recentSubmissions.map((submission) => {
                        const exercise = getExerciseById(submission.exercise_id);
                        if (!exercise) return null;
                        
                        return (
                            <TableRow key={submission.id}>
                                <TableCell className="font-medium max-w-sm truncate">{exercise.question}</TableCell>
                                <TableCell>
                                    <Badge variant={getScoreVariant(submission.score ?? 0)}>
                                        {submission.score ?? 0}/10
                                    </Badge>
                                </TableCell>
                                <TableCell className="hidden md:table-cell text-muted-foreground max-w-xs truncate">
                                    {submission.ai_feedback}
                                </TableCell>
                                <TableCell className="text-left text-muted-foreground">
                                    {format(new Date(submission.submitted_at), "d MMMM yyyy", { locale: ar })}
                                </TableCell>
                            </TableRow>
                        )
                    })
                ) : (
                    <TableRow>
                        <TableCell colSpan={4} className="text-center h-24">
                            لم يقم {child.prenom} بحل أي تمارين بعد.
                        </TableCell>
                    </TableRow>
                )}
                </TableBody>
            </Table>
        </CardContent>
       </Card>
    </div>
  );
}
