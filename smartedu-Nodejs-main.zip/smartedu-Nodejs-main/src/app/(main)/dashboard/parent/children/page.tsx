
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getChildrenOfParent, getSubmissionsForStudent, getExercisesForLesson, getLessonById } from "@/lib/mock-data";
import { Eye, TrendingUp, BookCheck, Target, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function MyChildrenPage() {
    const parentId = 4; // Mock parent ID
    const children = getChildrenOfParent(parentId);

    const getChildStats = (studentId: number) => {
        const submissions = getSubmissionsForStudent(studentId);
        const completedLessons = new Set(
            submissions
                .map(s => getLessonById(getExercisesForLesson(s.exercise_id)[0]?.lesson_id)?.id)
                .filter(Boolean)
        ).size;
        
        const totalScore = submissions.reduce((acc, s) => acc + (s.score ?? 0), 0);
        const averageScore = submissions.length > 0 ? Math.round((totalScore / (submissions.length * 10)) * 100) : 0;

        return {
            completedLessons,
            averageScore,
            submissionCount: submissions.length,
        };
    }

    return (
        <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">أبنائي</h1>
                    <p className="text-muted-foreground">
                        تابع تقدم أبنائك المرتبطين بحسابك.
                    </p>
                </div>
            </div>

            {children.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {children.map(child => {
                        const stats = getChildStats(child.id);
                        return (
                             <Card key={child.id}>
                                <CardHeader className="flex flex-row items-center gap-4">
                                    <Avatar className="h-16 w-16">
                                        <AvatarImage src={child.avatar} alt={child.name} />
                                        <AvatarFallback>{child.prenom.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div className="grid gap-1">
                                        <CardTitle>{child.name}</CardTitle>
                                        <CardDescription>{child.email}</CardDescription>
                                    </div>
                                </CardHeader>
                                <CardContent className="grid grid-cols-3 gap-4 text-center">
                                    <div className="p-3 bg-muted rounded-md">
                                        <BookCheck className="h-6 w-6 mx-auto mb-2 text-primary" />
                                        <p className="text-xl font-bold">{stats.completedLessons}</p>
                                        <p className="text-xs text-muted-foreground">دروس مكتملة</p>
                                    </div>
                                    <div className="p-3 bg-muted rounded-md">
                                        <Target className="h-6 w-6 mx-auto mb-2 text-primary" />
                                        <p className="text-xl font-bold">{stats.averageScore}%</p>
                                        <p className="text-xs text-muted-foreground">متوسط الدرجات</p>
                                    </div>
                                    <div className="p-3 bg-muted rounded-md">
                                        <TrendingUp className="h-6 w-6 mx-auto mb-2 text-primary" />
                                        <p className="text-xl font-bold">{stats.submissionCount}</p>
                                        <p className="text-xs text-muted-foreground">تمارين محلولة</p>
                                    </div>
                                </CardContent>
                                <CardFooter>
                                     <Link href={`/dashboard/parent/children/${child.id}`} className="w-full" passHref>
                                        <Button className="w-full">
                                            <span>عرض التقرير المفصل</span>
                                            <ArrowLeft className="mr-2 h-4 w-4" />
                                        </Button>
                                     </Link>
                                </CardFooter>
                            </Card>
                        )
                    })}
                </div>
            ) : (
                <Card className="flex flex-col items-center justify-center py-20">
                    <CardHeader>
                        <CardTitle>لم يتم ربط أي أبناء</CardTitle>
                        <CardDescription>استخدم كود الربط الموجود في لوحة التحكم لربط حسابات أبنائك.</CardDescription>
                    </CardHeader>
                </Card>
            )}
        </div>
    );
}
