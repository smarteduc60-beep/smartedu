
'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { getChildrenOfParent, getSubmissionsForStudents, getSubjects, getLessons, getExercisesForLesson } from "@/lib/mock-data";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  RadialBarChart,
  RadialBar
} from "recharts";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function ReportsPage() {
    const parentId = 4; // Mock parent ID
    const children = getChildrenOfParent(parentId);
    const childrenIds = children.map(c => c.id);
    const allSubmissions = getSubmissionsForStudents(childrenIds);
    const subjects = getSubjects();

    const childrenAverageScores = children.map(child => {
        const submissions = allSubmissions.filter(s => s.student_id === child.id);
        if (submissions.length === 0) return { name: child.prenom, averageScore: 0 };
        const totalScore = submissions.reduce((acc, s) => acc + (s.score ?? 0), 0);
        return { name: child.prenom, averageScore: Math.round(totalScore / submissions.length) * 10 };
    });

    const getChildScoreDistribution = (childId: number) => {
        const submissions = allSubmissions.filter(s => s.student_id === childId);
        const distribution = [
            { name: 'ممتاز (8-10)', value: submissions.filter(s => (s.score ?? 0) >= 8).length, color: 'hsl(var(--chart-2))' },
            { name: 'جيد (5-7)', value: submissions.filter(s => (s.score ?? 0) >= 5 && (s.score ?? 0) < 8).length, color: 'hsl(var(--chart-4))' },
            { name: 'ضعيف (0-4)', value: submissions.filter(s => (s.score ?? 0) < 5).length, color: 'hsl(var(--destructive))' },
        ];
        return distribution.filter(d => d.value > 0);
    };

    return (
        <div className="flex flex-col gap-8">
            <div className="grid gap-1">
                <h1 className="text-3xl font-bold tracking-tight">تقارير الأداء</h1>
                <p className="text-muted-foreground">
                    نظرة مقارنة على أداء أبنائك الدراسي.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>مقارنة متوسط الدرجات</CardTitle>
                    <CardDescription>
                        مقارنة بين متوسط الدرجات الكلي لكل ابن.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={childrenAverageScores}>
                            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(value) => `${value}%`} />
                            <Tooltip
                                cursor={{ fill: 'hsl(var(--accent) / 0.2)' }}
                                content={({ active, payload, label }) => {
                                if (active && payload && payload.length) {
                                    return (
                                    <div className="rounded-lg border bg-background p-2 shadow-sm">
                                        <p className="font-bold">{label}</p>
                                        <p className="text-sm text-primary">{`متوسط الدرجات: ${payload[0].value}%`}</p>
                                    </div>
                                    )
                                }
                                return null
                                }}
                            />
                            <Bar dataKey="averageScore" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                {children.map(child => {
                    const scoreDistribution = getChildScoreDistribution(child.id);
                    return (
                        <Card key={child.id}>
                            <CardHeader className="flex flex-row items-center gap-4">
                                <Avatar className="h-12 w-12">
                                    <AvatarImage src={child.avatar} alt={child.name} />
                                    <AvatarFallback>{child.prenom.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <CardTitle>توزيع درجات {child.prenom}</CardTitle>
                                    <CardDescription>نظرة على توزيع درجاته.</CardDescription>
                                </div>
                            </CardHeader>
                            <CardContent>
                                {scoreDistribution.length > 0 ? (
                                    <ResponsiveContainer width="100%" height={250}>
                                        <PieChart>
                                            <Pie data={scoreDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                                {scoreDistribution.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                                ))}
                                            </Pie>
                                            <Tooltip content={({ active, payload }) => {
                                                if (active && payload && payload.length) {
                                                    return (
                                                    <div className="rounded-lg border bg-background p-2 shadow-sm">
                                                        <p className="text-sm">{`${payload[0].name}: ${payload[0].value}`}</p>
                                                    </div>
                                                    )
                                                }
                                                return null
                                                }}
                                            />
                                            <Legend />
                                        </PieChart>
                                    </ResponsiveContainer>
                                ) : (
                                    <p className="text-muted-foreground text-center py-10">
                                        لم يقم {child.prenom} بحل أي تمارين بعد.
                                    </p>
                                )}
                            </CardContent>
                        </Card>
                    )
                })}
            </div>
        </div>
    );
}
