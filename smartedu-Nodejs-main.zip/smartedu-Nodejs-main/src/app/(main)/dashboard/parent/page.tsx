import ParentDashboard from "../_components/ParentDashboard";

export default function ParentDashboardPage() {
    // We assume parent ID is 4 for now
    return <ParentDashboard parentId={4} />
}
