
'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getChildrenOfParent, getSubmissionsForStudents, getExerciseById, getUserById, getLessonById, getSubjectById } from "@/lib/mock-data";
import { Bell, CheckCircle2, AlertTriangle, AlertCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotificationsPage() {
    const parentId = 4; // Mock parent ID
    const children = getChildrenOfParent(parentId);
    const childrenIds = children.map(c => c.id);
    const submissions = getSubmissionsForStudents(childrenIds).sort((a,b) => new Date(b.submitted_at).getTime() - new Date(a.submitted_at).getTime());

    const getNotificationDetails = (score: number) => {
        if (score >= 8) {
            return { 
                icon: CheckCircle2, 
                color: "text-green-600 dark:text-green-400", 
                title: "إنجاز رائع!",
                bgClassName: "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800"
            };
        }
        if (score > 5) { // Score is 6 or 7
            return { 
                icon: AlertTriangle, 
                color: "text-yellow-600 dark:text-yellow-400", 
                title: "أداء جيد، يمكن تحسينه",
                bgClassName: "bg-yellow-50 border-yellow-200 dark:bg-yellow-950 dark:border-yellow-800"
            };
        }
        // Score is 5 or less
        return { 
            icon: AlertCircle, 
            color: "text-red-600 dark:text-red-400", 
            title: "يحتاج إلى مراجعة",
            bgClassName: "bg-red-50 border-red-200 dark:bg-red-950 dark:border-red-800"
        };
    };
    
    return (
        <div className="flex flex-col gap-8">
            <div className="grid gap-1">
                <h1 className="text-3xl font-bold tracking-tight">الإشعارات</h1>
                <p className="text-muted-foreground">
                    آخر التحديثات والأنشطة المتعلقة بأبنائك.
                </p>
            </div>
             <Card>
                <CardHeader>
                    <CardTitle>آخر الأنشطة</CardTitle>
                    <CardDescription>
                       لديك {submissions.length} إشعار جديد بخصوص نشاط أبنائك.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                   {submissions.length > 0 ? (
                    <div className="space-y-4">
                        {submissions.map(submission => {
                            const student = getUserById(submission.student_id);
                            const exercise = getExerciseById(submission.exercise_id);
                            if (!student || !exercise) return null;

                            const lesson = getLessonById(exercise.lesson_id);
                            if(!lesson) return null;

                            const subject = getSubjectById(lesson.subject_id);
                            const details = getNotificationDetails(submission.score ?? 0);
                            const Icon = details.icon;

                            return (
                                <div key={submission.id} className={cn("flex gap-4 items-start p-4 rounded-lg border", details.bgClassName)}>
                                    <Avatar className="h-11 w-11 border-2 border-primary/20 mt-1">
                                        <AvatarImage src={student.avatar} alt={student.name} />
                                        <AvatarFallback>{student.prenom.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start">
                                            <p className="leading-relaxed text-sm">
                                                قام ابنك <span className="font-bold">{student.name}</span> بإكمال درس "{lesson.title}" من مادة "{subject?.name}".
                                                وقام بحل تمرين "{exercise.question}" وتحصل على العلامة <span className="font-bold text-primary">{submission.score ?? 0}/10</span> بعد المحاولة رقم <span className="font-bold">{submission.attempt_number}</span>.
                                            </p>
                                            <span className="text-xs text-muted-foreground whitespace-nowrap pt-1">
                                                {formatDistanceToNow(new Date(submission.submitted_at), { addSuffix: true, locale: ar })}
                                            </span>
                                        </div>
                                        <div className="mt-3 flex items-center gap-4">
                                            <div className={cn("flex items-center gap-2", details.color)}>
                                                <Icon className="h-5 w-5" />
                                                <span className="font-semibold text-sm">{details.title}</span>
                                            </div>
                                             <Link href={`/dashboard/parent/children/${student.id}`} passHref>
                                                <Button variant="link" size="sm" className="px-0 h-auto text-foreground/80 hover:text-foreground">عرض التقرير الكامل للطالب</Button>
                                             </Link>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                   ) : (
                    <div className="text-center text-muted-foreground py-12 flex flex-col items-center gap-4">
                        <Bell className="h-16 w-16 text-muted-foreground/50" />
                        <p>لا توجد إشعارات جديدة. سيتم عرضها هنا عند توفرها.</p>
                    </div>
                   )}
                </CardContent>
            </Card>
        </div>
    );
}
