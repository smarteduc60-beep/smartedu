import { getUserById } from "@/lib/mock-data";
import { redirect } from "next/navigation";

export default function DashboardPage() {
  // We'll check for the user's role and redirect accordingly.
  // For now, let's assume we have a way to get the current user.
  // Let's use the director user (ID 3) for now to show their dashboard.
  const user = getUserById(3); 

  if (user?.role === 'teacher') {
    redirect('/dashboard/teacher');
  } else if (user?.role === 'student') {
    redirect('/dashboard/student');
  } else if (user?.role === 'parent') {
    redirect('/dashboard/parent');
  } else if (user?.role === 'supervisor_specific') {
    redirect('/dashboard/subject-supervisor');
  } else if (user?.role === 'directeur') {
    redirect('/dashboard/directeur');
  }
  else {
    // Fallback for other roles or if user is not found
    // For now, redirect to login, but this could be a generic dashboard or an error page.
    redirect('/login');
  }

  // This return is technically unreachable due to redirects but is good practice.
  return <div>Loading...</div>;
}
