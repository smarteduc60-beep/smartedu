'use client';

import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getParent, getChildrenOfParent, getSubmissionsForStudents, getUserById } from "@/lib/mock-data";
import { Users, BarChart2, MessageSquare, PlusCircle, ArrowLeft, User, Eye, Copy } from "lucide-react";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";


export default function ParentDashboard({ parentId = 4 }: { parentId?: number }) {
    const { toast } = useToast();
    const parent = getParent(parentId);
    if (!parent) return <div>لم يتم العثور على حساب ولي الأمر.</div>;

    const children = getChildrenOfParent(parent.id);
    const childrenIds = children.map(c => c.id);
    const submissions = getSubmissionsForStudents(childrenIds);

    const handleCopy = () => {
        navigator.clipboard.writeText(parent.parent_code);
        toast({
            title: "تم النسخ!",
            description: "تم نسخ كود الربط إلى الحافظة.",
        });
    };

    // Calculate statistics
    const totalScore = submissions.reduce((acc, s) => acc + (s.score ?? 0), 0);
    const totalPossibleScore = submissions.length * 10;
    const averageScore = totalPossibleScore > 0 ? Math.round((totalScore / totalPossibleScore) * 100) : 0;
    
    // Mock unread messages
    const unreadMessages = 2; 

    return (
        <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">
                        أهلاً بك، {parent?.name}!
                    </h1>
                    <p className="text-muted-foreground">
                        هذه لوحة التحكم الخاصة بك لمتابعة تقدم أبنائك.
                    </p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">الأبناء المرتبطون</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{children.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي عدد الأبناء</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">متوسط الدرجات</CardTitle>
                        <BarChart2 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{averageScore}%</div>
                        <p className="text-xs text-muted-foreground">متوسط درجات جميع الأبناء</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">الرسائل غير المقروءة</CardTitle>
                        <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{unreadMessages}</div>
                        <p className="text-xs text-muted-foreground">لديك رسائل جديدة</p>
                    </CardContent>
                </Card>
            </div>
            
            <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>كود الربط الخاص بك</CardTitle>
                        <CardDescription>
                            شارك هذا الكود مع أبنائك لربط حساباتهم بحسابك.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="flex items-center gap-4">
                        <Input readOnly defaultValue={parent.parent_code} className="text-lg font-mono tracking-widest text-center" />
                        <Button variant="outline" onClick={handleCopy}>
                            <Copy className="ml-2 h-4 w-4" />
                            نسخ الكود
                        </Button>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>روابط سريعة</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 gap-4">
                        <Link href="/dashboard/parent/children" passHref><Button variant="secondary" className="w-full justify-start">عرض الأبناء</Button></Link>
                        <Link href="/dashboard/parent/reports" passHref><Button variant="secondary" className="w-full justify-start">عرض التقارير</Button></Link>
                        <Link href="/messages" passHref><Button variant="secondary" className="w-full justify-start">الرسائل</Button></Link>
                        <Link href="/profile" passHref><Button variant="secondary" className="w-full justify-start">الملف الشخصي</Button></Link>
                    </CardContent>
                </Card>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                        <span>نظرة سريعة على الأبناء</span>
                         <Link href="/dashboard/parent/children" passHref>
                            <Button variant="ghost" size="sm">
                                <span>عرض الكل</span>
                                <ArrowLeft className="mr-2 h-4 w-4" />
                            </Button>
                        </Link>
                    </CardTitle>
                    <CardDescription>آخر النشاطات والتقدم لأبنائك.</CardDescription>
                </CardHeader>
                <CardContent>
                    {children.length > 0 ? (
                        <div className="space-y-4">
                            {children.map(child => (
                                <div key={child.id} className="flex items-center justify-between p-3 rounded-lg border bg-muted/50">
                                    <div className="flex items-center gap-4">
                                        <Avatar>
                                            <AvatarImage src={child.avatar} alt={child.name} />
                                            <AvatarFallback>{child.prenom.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <p className="font-semibold">{child.name}</p>
                                            <p className="text-sm text-muted-foreground">{child.email}</p>
                                        </div>
                                    </div>
                                    <Link href={`/dashboard/parent/children/${child.id}`} passHref>
                                        <Button variant="outline" size="sm">
                                            <Eye className="ml-2 h-4 w-4" />
                                            <span>عرض التفاصيل</span>
                                        </Button>
                                    </Link>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-muted-foreground text-center py-8">لم يتم ربط أي أبناء بعد.</p>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
