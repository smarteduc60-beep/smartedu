import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getLessons, getStudent, getUserById, USERS, getSubmissionsForStudent, getExerciseById } from "@/lib/mock-data";
import { ArrowLeft, BarChart2, BookCheck, Link as LinkIcon, PlayCircle, UserMinus, UserCheck } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function StudentDashboard({ studentId = 1 }: { studentId?: number }) {
  const student = getStudent(studentId);
  const lessons = getLessons();
  const firstLesson = lessons[0];
  const lessonImage = PlaceHolderImages.find(img => img.id === 'lesson1');
  const teacher = USERS.find(u => u.role === 'teacher' && u.teacher_code === student?.connected_teacher_code);
  const parent = student?.parent_id ? USERS.find(u => u.id === student.parent_id) : null;
  const submissions = getSubmissionsForStudent(studentId);

  if (!student) {
      return <div>Student not found</div>
  }

  // Calculate statistics
  const completedLessons = new Set(
    submissions
      .map(s => getExerciseById(s.exercise_id)?.lesson_id)
      .filter(Boolean)
  ).size;

  const totalScore = submissions.reduce((acc, s) => acc + (s.score ?? 0), 0);
  const averageScore = submissions.length > 0 ? Math.round((totalScore / (submissions.length * 10)) * 100) : 0;
  
  const recentSubmissions = submissions.slice(-2).map(s => {
    const exercise = getExerciseById(s.exercise_id);
    return {...s, exerciseQuestion: exercise?.question ?? ''};
  }).reverse();


  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <div className="grid gap-1">
            <h1 className="text-3xl font-bold tracking-tight">
                أهلاً بك مجدداً، {student?.prenom}!
            </h1>
            <p className="text-muted-foreground">
                لنواصل رحلتنا التعليمية ونحقق المزيد من التقدم.
            </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PlayCircle className="text-primary" />
              <span>أكمل من حيث توقفت</span>
            </CardTitle>
            <CardDescription>
                أكمل درس "{firstLesson.title}" لتعزيز فهمك.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
             {lessonImage && (
              <div className="relative aspect-video w-full overflow-hidden rounded-lg">
                <Image
                  src={lessonImage.imageUrl}
                  alt={firstLesson.title}
                  fill
                  className="object-cover"
                  data-ai-hint={lessonImage.imageHint}
                />
              </div>
            )}
            <p className="text-muted-foreground">{firstLesson.content.substring(0, 150)}...</p>
            <Link href={`/lessons/${firstLesson.id}`}>
              <Button className="w-full lg:w-auto">
                <span>متابعة الدرس</span>
                <ArrowLeft className="mr-2 h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        <div className="space-y-6">
            <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <BarChart2 className="text-primary" />
                    <span>إحصائياتي</span>
                </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4 text-center">
                <div className="rounded-lg bg-accent/20 p-4">
                    <p className="text-3xl font-bold">{completedLessons}</p>
                    <p className="text-sm text-muted-foreground">دروس مكتملة</p>
                </div>
                <div className="rounded-lg bg-accent/20 p-4">
                    <p className="text-3xl font-bold">{averageScore}%</p>
                    <p className="text-sm text-muted-foreground">متوسط الدرجات</p>
                </div>
            </CardContent>
            </Card>

            <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <BookCheck className="text-primary" />
                    <span>آخر التقييمات</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                {recentSubmissions.length > 0 ? (
                    <ul className="space-y-3">
                        {recentSubmissions.map(submission => (
                            <li key={submission.id} className="flex items-center justify-between">
                                <span className="truncate max-w-40">{submission.exerciseQuestion}</span>
                                <span className="font-bold text-primary">{submission.score ?? 0}/10</span>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-muted-foreground text-center">لم تقم بحل أي تمارين بعد.</p>
                )}
            </CardContent>
            </Card>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <LinkIcon className="text-primary" />
                <span>ربط حساب المعلم</span>
            </CardTitle>
            <CardDescription>
                {teacher
                ? `أنت مرتبط حاليًا بالمعلم: ${teacher.name}.`
                : "أدخل كود المعلم الخاص بك للوصول إلى المحتوى الخاص."}
            </CardDescription>
            </CardHeader>
            <CardContent>
            {teacher ? (
                <div className="flex items-center justify-between rounded-lg border p-4 bg-muted/50">
                    <span className="font-semibold">{teacher.name} ({teacher.email})</span>
                    <Button variant="destructive" size="sm">
                        <UserMinus className="ml-2 h-4 w-4" />
                        <span>إلغاء الربط</span>
                    </Button>
                </div>
            ) : (
                <div className="flex items-center gap-2">
                    <Input id="teacher-code" placeholder="أدخل كود المعلم هنا" />
                    <Button>ربط الحساب</Button>
                </div>
            )}
            </CardContent>
        </Card>

        {parent && (
             <Card>
                <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <UserCheck className="text-primary" />
                    <span>ولي الأمر المرتبط</span>
                </CardTitle>
                <CardDescription>
                    حساب ولي أمرك مرتبط، ويمكنه متابعة تقدمك.
                </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center justify-between rounded-lg border p-4 bg-muted/50">
                        <div className="flex items-center gap-3">
                            <Avatar>
                                <AvatarImage src={parent.avatar} alt={parent.name} />
                                <AvatarFallback>{parent.prenom.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span className="font-semibold">{parent.name}</span>
                        </div>
                    </div>
                </CardContent>
            </Card>
        )}
      </div>

    </div>
  );
}
