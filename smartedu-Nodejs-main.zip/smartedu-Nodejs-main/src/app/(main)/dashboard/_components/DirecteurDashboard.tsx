
'use client';

import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { getLessons, getSubjects, getUserById, USERS } from "@/lib/mock-data";
import { Users, BookCopy, BarChart3, CheckCircle, Clock, XCircle, Eye, Database, Settings } from "lucide-react";
import Link from "next/link";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function DirecteurDashboard({ directeurId }: { directeurId: number }) {
    const directeur = getUserById(directeurId);
    if (!directeur) return <div>لم يتم العثور على حساب المدير.</div>;

    const allUsers = USERS;
    const teachers = allUsers.filter(u => u.role === 'teacher' || u.role === 'supervisor_specific');
    const students = allUsers.filter(u => u.role === 'student');
    const lessons = getLessons();
    const subjects = getSubjects();

    // In a real app, these statuses would be dynamic
    const approvedLessonsCount = lessons.filter(l => l.author_id !== 3).length; // Assuming director approval is for non-director lessons
    const pendingLessons = lessons.filter(l => l.author_id !== 3).slice(0,2); // Mock some pending
    const rejectedLessonsCount = 1; // Mock data

    const getStatusText = (status?: string) => {
        switch (status) {
            case 'pending': return 'قيد المراجعة';
            case 'approved': return 'معتمد';
            case 'rejected': return 'مرفوض';
            default: return 'معتمد'; // Default to approved for mock
        }
    };

    const getStatusVariant = (status?: string) => {
        switch (status) {
            case 'pending': return 'secondary';
            case 'approved': return 'default';
            case 'rejected': return 'destructive';
            default: return 'default';
        }
    };

    return (
        <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">
                        أهلاً بك، {directeur?.name}!
                    </h1>
                    <p className="text-muted-foreground">
                        نظرة عامة على أداء المنصة التعليمية.
                    </p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{allUsers.length}</div>
                        <p className="text-xs text-muted-foreground">جميع الأدوار</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">المعلمون والمشرفون</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{teachers.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي الطاقم التعليمي</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">الطلاب</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{students.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي الطلاب المسجلين</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">الدروس</CardTitle>
                        <BookCopy className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{lessons.length}</div>
                         <p className="text-xs text-muted-foreground flex flex-wrap gap-x-2">
                            <span className="flex items-center gap-1"><CheckCircle className="h-3 w-3 text-green-500" />{approvedLessonsCount}</span>
                            <span className="flex items-center gap-1"><Clock className="h-3 w-3 text-yellow-500" />{pendingLessons.length}</span>
                            <span className="flex items-center gap-1"><XCircle className="h-3 w-3 text-red-500" />{rejectedLessonsCount}</span>
                        </p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">المواد الدراسية</CardTitle>
                        <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{subjects.length}</div>
                        <p className="text-xs text-muted-foreground">إجمالي المواد المتاحة</p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid gap-6 grid-cols-1 xl:grid-cols-3">
                <Card className="xl:col-span-2">
                     <CardHeader>
                        <CardTitle>الدروس التي تحتاج مراجعة</CardTitle>
                        <CardDescription>
                            قائمة بالدروس التي أضافها المعلمون وتنتظر موافقتك.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                         <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>الدرس</TableHead>
                                    <TableHead>المعلم</TableHead>
                                    <TableHead>تاريخ الإنشاء</TableHead>
                                    <TableHead>الحالة</TableHead>
                                    <TableHead className="text-left">الإجراء</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                            {pendingLessons.length > 0 ? (
                                pendingLessons.map((lesson) => {
                                const author = getUserById(lesson.author_id);
                                return (
                                    <TableRow key={lesson.id}>
                                        <TableCell className="font-medium">{lesson.title}</TableCell>
                                        <TableCell>{author?.name ?? 'غير معروف'}</TableCell>
                                        <TableCell>{format(new Date(), "d MMMM yyyy", { locale: ar })}</TableCell>
                                        <TableCell>
                                            <Badge variant={getStatusVariant('pending')}>{getStatusText('pending')}</Badge>
                                        </TableCell>
                                        <TableCell className="text-left">
                                            <Link href={`/dashboard/directeur/review-lesson/${lesson.id}`} passHref>
                                            <Button variant="outline" size="sm">
                                                <Eye className="ml-2 h-4 w-4" />
                                                مراجعة
                                            </Button>
                                            </Link>
                                        </TableCell>
                                    </TableRow>
                                );
                                })
                            ) : (
                                <TableRow>
                                <TableCell colSpan={5} className="text-center h-24">
                                    لا توجد دروس بانتظار المراجعة حاليًا.
                                </TableCell>
                                </TableRow>
                            )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle>روابط سريعة</CardTitle>
                        <CardDescription>وصول سريع لأقسام الإدارة الرئيسية.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 gap-4">
                        <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/users"><Users className="ml-2"/>إدارة المستخدمين</Link>
                        </Button>
                        <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/content"><BookCopy className="ml-2"/>إدارة المحتوى</Link>
                        </Button>
                        <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/database"><Database className="ml-2"/>قاعدة البيانات</Link>
                        </Button>
                         <Button variant="secondary" className="justify-start w-full" asChild>
                            <Link href="/dashboard/directeur/settings"><Settings className="ml-2"/>الإعدادات</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
