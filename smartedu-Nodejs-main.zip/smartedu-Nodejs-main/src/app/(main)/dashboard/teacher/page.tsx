import TeacherDashboard from "../_components/TeacherDashboard";

export default function TeacherDashboardPage() {
    return <TeacherDashboard />
}
