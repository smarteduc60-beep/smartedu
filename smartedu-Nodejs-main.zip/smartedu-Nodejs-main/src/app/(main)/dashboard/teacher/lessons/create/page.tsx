'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { SUBJECTS, LEVELS } from "@/lib/mock-data";
import { Save, UploadCloud } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

export default function CreateLessonPage() {

  // A teacher can only create private lessons, so we don't show the switch.
  // We assume the form submission will enforce this.

  return (
    <div className="flex flex-col gap-8 max-w-4xl mx-auto">
      <div className="grid gap-1">
        <h1 className="text-3xl font-bold tracking-tight">إنشاء درس جديد</h1>
        <p className="text-muted-foreground">
          املأ النموذج أدناه لإضافة درس جديد إلى المنصة. ستكون كل الدروس التي تنشئها خاصة بطلابك المرتبطين بك.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>تفاصيل الدرس</CardTitle>
          <CardDescription>
            أدخل المعلومات الأساسية لدرسك.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">عنوان الدرس</Label>
              <Input id="title" placeholder="مثال: مقدمة في الجبر" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="subject">المادة</Label>
                <Select>
                  <SelectTrigger id="subject">
                    <SelectValue placeholder="اختر المادة" />
                  </SelectTrigger>
                  <SelectContent>
                    {SUBJECTS.map((subject) => (
                      <SelectItem key={subject.id} value={String(subject.id)}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="level">المستوى</Label>
                 <Select>
                  <SelectTrigger id="level">
                    <SelectValue placeholder="اختر المستوى" />
                  </SelectTrigger>
                  <SelectContent>
                    {LEVELS.map((level) => (
                      <SelectItem key={level.id} value={String(level.id)}>
                        {level.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">محتوى الدرس</Label>
              <Textarea id="content" placeholder="اكتب محتوى الدرس هنا..." rows={10} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="video-url">رابط الفيديو (يوتيوب)</Label>
              <Input id="video-url" placeholder="https://www.youtube.com/watch?v=..." />
            </div>
            
            <div className="space-y-2">
                <Label>المرفقات (اختياري)</Label>
                <div className="flex items-center justify-center w-full">
                    <Label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-muted hover:bg-muted/80">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                            <UploadCloud className="w-8 h-8 mb-4 text-muted-foreground" />
                            <p className="mb-2 text-sm text-muted-foreground"><span className="font-semibold">انقر للرفع</span> أو اسحب وأفلت الملفات</p>
                            <p className="text-xs text-muted-foreground">PDF, PNG, JPG (بحد أقصى 5 ميجابايت)</p>
                        </div>
                        <Input id="dropzone-file" type="file" className="hidden" multiple />
                    </Label>
                </div> 
            </div>

            <div className="flex justify-end">
              <Button type="submit">
                <Save className="ml-2 h-4 w-4" />
                <span>حفظ الدرس</span>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
