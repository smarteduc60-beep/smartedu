
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { getSubmissionsForStudent, getExerciseById, getLessonById } from "@/lib/mock-data";
import { Eye, BookOpen } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function MyResultsPage() {
    const studentId = 1; // Mock student ID
    const submissions = getSubmissionsForStudent(studentId).sort((a,b) => new Date(b.submitted_at).getTime() - new Date(a.submitted_at).getTime());

    const getScoreVariant = (score: number) => {
        if (score >= 8) return 'default';
        if (score >= 5) return 'secondary';
        return 'destructive';
    }

    return (
        <div className="flex flex-col gap-8">
            <div className="grid gap-1">
                <h1 className="text-3xl font-bold tracking-tight">نتائجي</h1>
                <p className="text-muted-foreground">
                    هنا يمكنك عرض جميع إجاباتك ونتائجك في التمارين.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>سجل الإجابات</CardTitle>
                    <CardDescription>
                        قائمة بجميع التمارين التي قمت بحلها والدرجات التي حصلت عليها.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>التمرين</TableHead>
                                <TableHead>الدرجة</TableHead>
                                <TableHead className="hidden md:table-cell">التقييم</TableHead>
                                <TableHead className="hidden md:table-cell text-center">تاريخ الإجابة</TableHead>
                                <TableHead className="text-center">الإجراء</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                        {submissions.length > 0 ? (
                            submissions.map((submission) => {
                                const exercise = getExerciseById(submission.exercise_id);
                                if (!exercise) return null;
                                
                                const lesson = getLessonById(exercise.lesson_id);

                                return (
                                    <TableRow key={submission.id}>
                                        <TableCell className="font-medium max-w-sm truncate">
                                            <p>{exercise.question}</p>
                                            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                                                <BookOpen className="h-3 w-3" />
                                                {lesson?.title}
                                            </p>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant={getScoreVariant(submission.score ?? 0)}>
                                                {submission.score ?? 0}/10
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="hidden md:table-cell text-muted-foreground max-w-xs truncate">
                                            {submission.ai_feedback}
                                        </TableCell>
                                        <TableCell className="hidden md:table-cell text-center text-muted-foreground">
                                           {format(new Date(submission.submitted_at), "d MMMM yyyy", { locale: ar })}
                                        </TableCell>
                                        <TableCell className="text-center">
                                            <Link href={`/lessons/${lesson?.id}`} passHref>
                                                <Button variant="ghost" size="icon" title="عرض الدرس">
                                                    <Eye className="h-4 w-4" />
                                                </Button>
                                            </Link>
                                        </TableCell>
                                    </TableRow>
                                )
                            })
                        ) : (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center">
                                    لم تقم بحل أي تمارين بعد.
                                </TableCell>
                            </TableRow>
                        )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}

