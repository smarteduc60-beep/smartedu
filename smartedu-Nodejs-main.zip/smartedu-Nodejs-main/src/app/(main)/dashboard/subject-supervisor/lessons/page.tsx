import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getLessons, getUserById, getExercisesForLesson } from "@/lib/mock-data";
import { PlusCircle, FilePenLine, Eye, Trash2, FileQuestion } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function SupervisorLessonsPage() {
  const supervisor = getUserById(7);
  // Filter lessons authored by the supervisor
  const lessons = getLessons().filter(l => l.author_id === supervisor?.id);

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <div className="grid gap-1">
          <h1 className="text-3xl font-bold tracking-tight">إدارة الدروس</h1>
          <p className="text-muted-foreground">
            قم بإدارة جميع الدروس العامة والخاصة التي قمت بإنشائها.
          </p>
        </div>
        <Link href="/dashboard/subject-supervisor/lessons/create" passHref>
          <Button>
            <PlusCircle className="ml-2 h-4 w-4" />
            <span>إنشاء درس جديد</span>
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة الدروس</CardTitle>
          <CardDescription>
            هذه هي جميع الدروس التي قمت بإنشائها.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>عنوان الدرس</TableHead>
                <TableHead>عدد التمارين</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead className="text-center">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lessons.length > 0 ? (
                lessons.map((lesson) => {
                    const exerciseCount = getExercisesForLesson(lesson.id).length;
                    return (
                        <TableRow key={lesson.id}>
                            <TableCell className="font-medium">{lesson.title}</TableCell>
                            <TableCell>
                                <div className="flex items-center gap-1">
                                    <FileQuestion className="h-4 w-4 text-muted-foreground" />
                                    {exerciseCount}
                                </div>
                            </TableCell>
                            <TableCell>
                               <Badge variant={lesson.type === 'public' ? 'outline' : 'secondary'}>
                                {lesson.type === 'public' ? 'عام' : 'خاص'}
                               </Badge>
                            </TableCell>
                            <TableCell className="text-center">
                                <div className="flex justify-center gap-2">
                                    <Link href={`/lessons/${lesson.id}`} passHref>
                                        <Button variant="ghost" size="icon" title="معاينة">
                                            <Eye className="h-4 w-4" />
                                        </Button>
                                    </Link>
                                    <Link href={`/dashboard/subject-supervisor/lessons/${lesson.id}/edit`} passHref>
                                        <Button variant="ghost" size="icon" title="تعديل">
                                            <FilePenLine className="h-4 w-4" />
                                        </Button>
                                    </Link>
                                    <Button variant="ghost" size="icon" title="حذف" className="text-destructive hover:text-destructive">
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                            </TableCell>
                        </TableRow>
                    )
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center">
                    لم تقم بإنشاء أي دروس بعد.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
