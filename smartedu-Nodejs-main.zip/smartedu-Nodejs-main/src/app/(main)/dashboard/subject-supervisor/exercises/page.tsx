
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getLessons, getExercisesForLesson, getUserById } from "@/lib/mock-data";
import { PlusCircle, FilePenLine, Trash2 } from "lucide-react";
import Link from "next/link";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Mock current user ID. This would come from auth.
const MOCK_SUPERVISOR_ID = 7;

export default function SupervisorExercisesPage() {
  const supervisor = getUserById(MOCK_SUPERVISOR_ID);
  if (!supervisor) return null;

  const lessons = getLessons().filter((l) => l.author_id === supervisor.id);
  const allExercises = lessons.flatMap(lesson => 
    getExercisesForLesson(lesson.id).map(ex => ({...ex, lessonTitle: lesson.title}))
  );

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <div className="grid gap-1">
          <h1 className="text-3xl font-bold tracking-tight">إدارة التمارين</h1>
          <p className="text-muted-foreground">
            قم بإدارة جميع التمارين التي قمت بإنشائها في دروسك.
          </p>
        </div>
        <Link href="/dashboard/subject-supervisor/exercises/create" passHref>
          <Button>
            <PlusCircle className="ml-2 h-4 w-4" />
            <span>إضافة تمرين جديد</span>
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة التمارين</CardTitle>
          <CardDescription>
            هذه هي جميع التمارين التي قمت بإضافتها إلى دروسك العامة والخاصة.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>نص السؤال</TableHead>
                <TableHead>الدرس المرتبط</TableHead>
                <TableHead className="text-center">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {allExercises.length > 0 ? (
                allExercises.map((exercise) => (
                    <TableRow key={exercise.id}>
                        <TableCell className="font-medium truncate max-w-md">{exercise.question}</TableCell>
                        <TableCell>{exercise.lessonTitle}</TableCell>
                        <TableCell className="text-center">
                            <div className="flex justify-center gap-2">
                                <Link href={`/dashboard/subject-supervisor/exercises/${exercise.id}/edit`} passHref>
                                    <Button variant="ghost" size="icon" title="تعديل">
                                        <FilePenLine className="h-4 w-4" />
                                    </Button>
                                </Link>
                                <Button variant="ghost" size="icon" title="حذف" className="text-destructive hover:text-destructive">
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        </TableCell>
                    </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={3} className="text-center h-24">
                    لم تقم بإنشاء أي تمارين بعد.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
