import SubjectSupervisorDashboard from "./_components/SubjectSupervisorDashboard";

export default function SubjectSupervisorDashboardPage() {
    // We assume supervisor ID is 7 for now
    return <SubjectSupervisorDashboard supervisorId={7} />
}
