'use client';

import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { getSubjectSupervisor, getLessons, USERS, getExercisesForLesson, getSubjectById, getUserById } from "@/lib/mock-data";
import { BookCopy, FileQuestion, PlusCircle, Eye } from "lucide-react";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function SubjectSupervisorDashboard({ supervisorId }: { supervisorId: number }) {
    const supervisor = getSubjectSupervisor(supervisorId);
    if (!supervisor || !supervisor.subject_id) return <div>لم يتم العثور على مشرف المادة أو المادة.</div>;

    const subject = getSubjectById(supervisor.subject_id);
    const lessons = getLessons().filter(l => l.subject_id === supervisor.subject_id && l.author_id === supervisor.id);
    const exercisesCount = lessons.reduce((acc, lesson) => acc + getExercisesForLesson(lesson.id).length, 0);

    return (
        <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
                <div className="grid gap-1">
                    <h1 className="text-3xl font-bold tracking-tight">
                        لوحة تحكم مشرف مادة "{subject?.name}"
                    </h1>
                    <p className="text-muted-foreground">
                        مرحباً بك، {supervisor?.name}! هنا يمكنك إدارة المحتوى العام لمادتك.
                    </p>
                </div>
                 <Link href="/dashboard/subject-supervisor/lessons/create" passHref>
                    <Button>
                        <PlusCircle className="ml-2 h-4 w-4" />
                        <span>إنشاء درس عام جديد</span>
                    </Button>
                </Link>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">إجمالي الدروس العامة</CardTitle>
                        <BookCopy className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{lessons.length}</div>
                        <p className="text-xs text-muted-foreground">دروس قمت بإنشائها</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">إجمالي التمارين</CardTitle>
                        <FileQuestion className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{exercisesCount}</div>
                        <p className="text-xs text-muted-foreground">في الدروس العامة التي أنشأتها</p>
                    </CardContent>
                </Card>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                        <span>أحدث الدروس العامة</span>
                    </CardTitle>
                    <CardDescription>هذه هي أحدث الدروس التي قمت بإضافتها.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>عنوان الدرس</TableHead>
                                <TableHead>النوع</TableHead>
                                <TableHead className="text-left">الإجراءات</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                        {lessons.slice(0, 5).map(lesson => {
                            return (
                                <TableRow key={lesson.id}>
                                    <TableCell className="font-medium">{lesson.title}</TableCell>
                                    <TableCell>
                                        <Badge variant="outline">{lesson.type === 'public' ? 'عام' : 'خاص'}</Badge>
                                    </TableCell>
                                    <TableCell className="text-left">
                                        <Link href={`/lessons/${lesson.id}`} passHref>
                                            <Button variant="outline" size="sm">
                                                <Eye className="ml-2 h-4 w-4" />
                                                معاينة الدرس
                                            </Button>
                                        </Link>
                                    </TableCell>
                                </TableRow>
                            )
                        })}
                        {lessons.length === 0 && (
                            <TableRow>
                                <TableCell colSpan={3} className="text-center h-24">
                                    لم تقم بإنشاء أي دروس بعد.
                                </TableCell>
                            </TableRow>
                        )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
