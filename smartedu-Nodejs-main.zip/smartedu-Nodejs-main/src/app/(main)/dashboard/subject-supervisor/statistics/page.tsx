
'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getLessons, getSubjectById, USERS } from "@/lib/mock-data";
import {
  BarChart,
  BookCopy,
  FileQuestion,
  Users,
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

export default function StatisticsPage() {
  const supervisorId = 7;
  const supervisor = USERS.find(u => u.id === supervisorId && u.role === 'supervisor_specific');

  if (!supervisor || !supervisor.subject_id) {
    return <div>لم يتم العثور على المشرف أو المادة.</div>;
  }

  const subject = getSubjectById(supervisor.subject_id);
  if (!subject) {
    return <div>لم يتم العثور على المادة.</div>;
  }
  
  const subjectLessons = getLessons().filter(l => l.subject_id === subject.id);
  const teachersInSubject = USERS.filter(u => u.role === 'teacher' && u.subject_id === subject.id).concat(supervisor.teacher_code ? [supervisor] : []);
  const teacherCodes = teachersInSubject.map(t => t.teacher_code).filter(Boolean) as string[];
  const studentsInSubject = USERS.filter(u => u.role === 'student' && u.connected_teacher_code && teacherCodes.includes(u.connected_teacher_code));

  const lessonTypeData = [
    { name: 'دروس عامة', value: subjectLessons.filter(l => l.type === 'public').length, color: 'hsl(var(--chart-1))' },
    { name: 'دروس خاصة', value: subjectLessons.filter(l => l.type === 'private').length, color: 'hsl(var(--chart-2))' },
  ];
  
  const topTeachers = teachersInSubject.map(teacher => {
    const teacherLessons = subjectLessons.filter(l => l.author_id === teacher.id);
    return {
      ...teacher,
      lessonCount: teacherLessons.length,
      publicLessons: teacherLessons.filter(l => l.type === 'public').length,
      privateLessons: teacherLessons.filter(l => l.type === 'private').length,
    }
  }).sort((a, b) => b.lessonCount - a.lessonCount).slice(0, 5);


  return (
    <div className="flex flex-col gap-8">
       <div className="grid gap-1">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <BarChart className="h-7 w-7 text-primary" />
            <span>إحصائيات مادة "{subject.name}"</span>
        </h1>
        <p className="text-muted-foreground">
          نظرة شاملة على أداء ونشاط المعلمين والطلاب في المادة.
        </p>
      </div>

       <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الدروس</CardTitle>
            <BookCopy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{subjectLessons.length}</div>
            <p className="text-xs text-muted-foreground">في هذه المادة</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي التمارين</CardTitle>
            <FileQuestion className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">120</div>
            <p className="text-xs text-muted-foreground">تم إنشاؤها في هذه المادة</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المعلمين</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teachersInSubject.length}</div>
            <p className="text-xs text-muted-foreground">يدرسون هذه المادة</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الطلاب</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{studentsInSubject.length}</div>
            <p className="text-xs text-muted-foreground">يدرسون هذه المادة</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>توزيع الدروس حسب النوع</CardTitle>
            <CardDescription>
                النسبة بين الدروس العامة والدروس الخاصة.
            </CardDescription>
          </CardHeader>
          <CardContent>
             <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={lessonTypeData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                  {lessonTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
         <Card>
          <CardHeader>
            <CardTitle>النشاط الشهري</CardTitle>
             <CardDescription>
                (ميزة قيد التطوير)
            </CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center text-muted-foreground h-[300px]">
            <p>سيتم عرض مخطط النشاط الشهري هنا قريباً.</p>
          </CardContent>
        </Card>
      </div>

       <Card>
        <CardHeader>
          <CardTitle>أفضل المعلمين أداءً</CardTitle>
          <CardDescription>قائمة بالمعلمين الأكثر نشاطاً في إضافة الدروس.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>المعلم</TableHead>
                <TableHead>إجمالي الدروس</TableHead>
                <TableHead>دروس عامة</TableHead>
                <TableHead>دروس خاصة</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {topTeachers.length > 0 ? topTeachers.map(teacher => (
                <TableRow key={teacher.id}>
                    <TableCell>
                        <div className="flex items-center gap-3">
                            <Avatar>
                                <AvatarImage src={teacher.avatar} alt={teacher.name} />
                                <AvatarFallback>{teacher.prenom.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span className="font-medium">{teacher.name}</span>
                        </div>
                    </TableCell>
                    <TableCell className="font-bold">{teacher.lessonCount}</TableCell>
                    <TableCell>{teacher.publicLessons}</TableCell>
                    <TableCell>{teacher.privateLessons}</TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      لا يوجد معلمون في هذه المادة بعد.
                    </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
