
'use client';

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { getMessagesForUser, getUserById, USERS, getChildrenOfParent } from "@/lib/mock-data";
import type { User } from "@/lib/types";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { Send } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { useSearchParams, usePathname } from "next/navigation";
import { useState, useEffect, useMemo } from "react";

// Helper function to determine the current user based on the path context
const getCurrentUser = (pathname: string | null) => {
    if (!pathname) return getUserById(1); // Default to student
    
    // This logic should mirror the one in SidebarNav to be consistent
    if (pathname.startsWith('/dashboard/subject-supervisor')) {
        return getUserById(7); // supervisor
    }
    if (pathname.startsWith('/dashboard/teacher')) {
        return getUserById(2); // teacher
    }
    if (pathname.startsWith('/dashboard/parent')) {
        return getUserById(4); // parent
    }
    // Default to student for /messages, /lessons, etc.
    return getUserById(1); // student
}

export default function MessagesPage() {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const recipientIdFromQuery = searchParams.get('recipient');
  
  const [currentUser, setCurrentUser] = useState<User | undefined | null>(null);

  useEffect(() => {
    // This is a trick for this prototype: we assume the user is the one corresponding
    // to the last major dashboard section they visited. This is not a robust
    // solution for a real app with auth, but works for navigation simulation.
    // We check a session storage item that could be set by the sidebar/layout.
    const rolePath = sessionStorage.getItem('currentRolePath') || pathname;
    setCurrentUser(getCurrentUser(rolePath));
  }, [pathname]);


  const currentUserId = currentUser?.id ?? 1; // Default to student if not loaded
  const messages = getMessagesForUser(currentUserId);
  
  const allPartners = useMemo(() => {
    if (!currentUser) return [];

    // Get partners from existing messages
    const partnersFromMessages = messages.reduce((acc, message) => {
        const partnerId = message.author_id === currentUserId ? message.recipient_id : message.author_id;
        const partner = getUserById(partnerId);
        if (partner && !acc.find(p => p.id === partner.id)) {
            acc.push(partner);
        }
        return acc;
    }, [] as User[]);

    let dynamicPartners: User[] = [];

    // If current user is a parent, find all teachers of their children
    if (currentUser.role === 'parent') {
        const children = getChildrenOfParent(currentUser.id);
        const teacherCodes = new Set(children.map(c => c.connected_teacher_code).filter(Boolean));
        dynamicPartners = USERS.filter(u => u.role === 'teacher' && u.teacher_code && teacherCodes.has(u.teacher_code));
    }
    // If current user is a teacher or a supervisor, find all parents of their students
    else if (currentUser.role === 'teacher' || currentUser.role === 'supervisor_specific') {
        const students = USERS.filter(u => u.role === 'student' && u.connected_teacher_code === currentUser.teacher_code);
        const parentIds = new Set(students.map(s => s.parent_id).filter((id): id is number => id !== undefined));
        dynamicPartners = USERS.filter(u => u.role === 'parent' && parentIds.has(u.id));
    }
    
    // Combine and remove duplicates
    const combined = [...partnersFromMessages, ...dynamicPartners];
    const uniquePartners = Array.from(new Map(combined.map(p => [p.id, p])).values());

    return uniquePartners;

  }, [messages, currentUserId, currentUser]);


  const [selectedPartnerId, setSelectedPartnerId] = useState<number | null>(null);

  useEffect(() => {
    if (recipientIdFromQuery) {
        const recipientUser = getUserById(Number(recipientIdFromQuery));
        if (recipientUser && allPartners.some(p => p.id === recipientUser.id)) {
            setSelectedPartnerId(recipientUser.id);
            return;
        }
    }
    
    if (allPartners.length > 0 && !selectedPartnerId) {
        // Find the partner with the most recent message to select by default
        const lastMessage = messages[0];
        if (lastMessage) {
            const partnerId = lastMessage.author_id === currentUserId ? lastMessage.recipient_id : lastMessage.author_id;
            if (allPartners.some(p => p.id === partnerId)) {
                setSelectedPartnerId(partnerId);
            } else {
                setSelectedPartnerId(allPartners[0].id);
            }
        } else {
             setSelectedPartnerId(allPartners[0].id);
        }
    }
  }, [recipientIdFromQuery, allPartners, messages, currentUserId, selectedPartnerId]);


  if (!currentUser) {
      return <div className="flex items-center justify-center h-full">Loading user...</div>
  }

  if (allPartners.length === 0) {
    return (
        <div className="flex flex-col gap-8 items-center justify-center h-full">
             <div className="grid gap-1 text-center">
                <h1 className="text-3xl font-bold tracking-tight">الرسائل</h1>
                <p className="text-muted-foreground">
                    لا توجد لديك أي محادثات حالياً.
                </p>
            </div>
        </div>
    )
  }
  
  const selectedPartner = getUserById(selectedPartnerId ?? 0);
  const conversationMessages = messages.filter(m => {
    const partnerId = m.author_id === currentUserId ? m.recipient_id : m.author_id;
    return partnerId === selectedPartnerId;
  });

  const roleName = (role?: string) => {
      if (!role) return '';
      return {
          teacher: 'معلم',
          student: 'طالب',
          parent: 'ولي أمر',
          directeur: 'مدير',
          supervisor_specific: 'مشرف مادة'
      }[role] || 'مستخدم';
  }


  return (
    <div className="h-[calc(100vh-5rem)] flex flex-col">
        <div className="flex items-center px-4 py-3 border-b">
            <h1 className="text-xl font-bold">الرسائل</h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] lg:grid-cols-[320px_1fr] h-full overflow-hidden">
            <div className="border-l flex flex-col">
                <div className="p-4">
                     <Input placeholder="البحث في الرسائل..."/>
                </div>
                <Separator />
                <ScrollArea className="flex-1">
                    <div className="flex flex-col gap-0 p-2">
                        {allPartners.map((partner) => {
                            const lastMessage = messages.find(m => {
                                const partnerId = m.author_id === currentUserId ? m.recipient_id : m.author_id;
                                return partnerId === partner.id;
                            });
                            return (
                                <button
                                    key={partner?.id}
                                    onClick={() => setSelectedPartnerId(partner.id)}
                                    className={cn(
                                        "flex flex-col items-start gap-2 rounded-lg border border-transparent p-3 text-left text-sm transition-all hover:bg-accent",
                                        partner?.id === selectedPartnerId && "bg-accent border-border"
                                    )}
                                >
                                    <div className="flex w-full items-center gap-3">
                                        <Avatar className="h-10 w-10">
                                            <AvatarImage src={partner?.avatar} alt={partner?.name} />
                                            <AvatarFallback>{partner?.name.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1 truncate">
                                            <div className="font-semibold">{partner?.name}</div>
                                            {lastMessage && <div className="text-xs text-muted-foreground truncate">{lastMessage.content}</div>}
                                        </div>
                                        {lastMessage && (
                                            <div className="text-xs text-muted-foreground self-start">
                                                {formatDistanceToNow(new Date(lastMessage.created_at), { addSuffix: true, locale: ar })}
                                            </div>
                                        )}
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                </ScrollArea>
            </div>

            {selectedPartner ? (
                <div className="flex flex-col h-full">
                    <div className="flex items-center gap-4 p-4 border-b">
                        <Avatar>
                            <AvatarImage src={selectedPartner?.avatar} alt={selectedPartner?.name} />
                            <AvatarFallback>{selectedPartner?.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <div className="font-semibold">{selectedPartner?.name}</div>
                            <div className="text-sm text-muted-foreground">{roleName(selectedPartner?.role)}</div>
                        </div>
                    </div>
                    <ScrollArea className="flex-1 p-4">
                        <div className="space-y-6">
                            {conversationMessages.map(message => {
                                const isMe = message.author_id === currentUserId;
                                const author = isMe ? currentUser : selectedPartner;
                                return (
                                    <div key={message.id} className={cn("flex items-end gap-3", isMe ? "justify-end" : "justify-start")}>
                                        {!isMe && 
                                            <Avatar className="h-9 w-9">
                                                <AvatarImage src={author?.avatar} />
                                                <AvatarFallback>{author?.name.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                        }
                                        <div className={cn("max-w-lg rounded-lg p-3", isMe ? "bg-primary text-primary-foreground" : "bg-muted")}>
                                            <p className="leading-relaxed">{message.content}</p>
                                            <p className={cn("text-xs mt-2 text-right", isMe ? "text-primary-foreground/70" : "text-muted-foreground")}>
                                                {formatDistanceToNow(new Date(message.created_at), { addSuffix: true, locale: ar })}
                                            </p>
                                        </div>
                                        {isMe && 
                                            <Avatar className="h-9 w-9">
                                                <AvatarImage src={author?.avatar} />
                                                <AvatarFallback>{author?.name.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                        }
                                    </div>
                                )
                            })}
                             {conversationMessages.length === 0 && (
                                <div className="text-center text-muted-foreground py-8">
                                    <p>ابدأ محادثة مع {selectedPartner.name}.</p>
                                </div>
                            )}
                        </div>
                    </ScrollArea>
                    <div className="p-4 border-t bg-background">
                        <form>
                            <div className="relative">
                                <Textarea placeholder="اكتب رسالتك..." className="pr-16" rows={1}/>
                                <Button type="submit" size="icon" className="absolute left-3 top-1/2 -translate-y-1/2">
                                    <Send className="h-5 w-5" />
                                    <span className="sr-only">إرسال</span>
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                    <p>اختر محادثة لعرض الرسائل.</p>
                </div>
            )}
        </div>
    </div>
  );
}

    