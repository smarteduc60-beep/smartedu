import Link from "next/link";
import Image from "next/image";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getSubjects, getLessons } from "@/lib/mock-data";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { ArrowLeft, BookOpen } from "lucide-react";

export default function SubjectsPage() {
  const subjects = getSubjects();
  const lessons = getLessons();

  const getSubjectImage = (subjectName: string) => {
    const imageName = `subject-${subjectName.toLowerCase()}`;
    // A simple mapping for demo purposes
    if (subjectName === 'الرياضيات') return PlaceHolderImages.find((img) => img.id === 'subject-math');
    if (subjectName === 'اللغة العربية') return PlaceHolderImages.find((img) => img.id === 'subject-arabic');
    if (subjectName === 'العلوم') return PlaceHolderImages.find((img) => img.id === 'subject-science');
    return null;
  };

  const getLessonCountForSubject = (subjectId: number) => {
    return lessons.filter(lesson => lesson.subject_id === subjectId).length;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">المواد الدراسية</h1>
        <p className="text-muted-foreground">
          تصفح المواد المتاحة لك وابدأ في استكشاف الدروس.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {subjects.map((subject) => {
          const subjectImage = getSubjectImage(subject.name);
          const lessonCount = getLessonCountForSubject(subject.id);
          return (
            <Card key={subject.id} className="flex flex-col overflow-hidden">
              {subjectImage && (
                <div className="relative aspect-video w-full">
                  <Image
                    src={subjectImage.imageUrl}
                    alt={subject.name}
                    fill
                    className="object-cover"
                    data-ai-hint={subjectImage.imageHint}
                  />
                </div>
              )}
              <CardHeader>
                <CardTitle className="text-xl">{subject.name}</CardTitle>
                <CardDescription>{subject.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                 <div className="flex items-center text-sm text-muted-foreground">
                    <BookOpen className="ml-2 h-4 w-4" />
                    <span>{lessonCount} {lessonCount === 1 ? 'درس متاح' : 'دروس متاحة'}</span>
                </div>
              </CardContent>
              <CardFooter>
                <Link href={`/lessons?subject=${subject.id}`} className="w-full" passHref>
                  <Button className="w-full">
                    <span>عرض الدروس</span>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
