
import { notFound } from "next/navigation";
import { getLessonById, getExercisesForLesson, getSubjectById, getSubmissionsForStudent } from "@/lib/mock-data";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { FileQuestion, Paperclip } from "lucide-react";
import ExerciseSubmission from "./components/ExerciseSubmission";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function LessonDetailPage({ params }: { params: { id: string } }) {
  const lesson = getLessonById(Number(params.id));
  if (!lesson) {
    notFound();
  }

  const exercises = getExercisesForLesson(lesson.id);
  const subject = getSubjectById(lesson.subject_id);
  
  // Mock student ID, this would come from session
  const studentId = 1;
  const submissions = getSubmissionsForStudent(studentId);

  let previousExerciseCompleted = true;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-2">{subject?.name}</Badge>
        <h1 className="text-4xl font-bold tracking-tight">{lesson.title}</h1>
      </div>

      <Card className="mb-8 overflow-hidden">
        {lesson.video_url && (
            <div className="aspect-video">
                <iframe
                    className="w-full h-full"
                    src={lesson.video_url?.replace('watch?v=', 'embed/')}
                    title={lesson.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                ></iframe>
            </div>
        )}
        <CardHeader>
          <CardTitle>محتوى الدرس</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-lg max-w-none dark:prose-invert text-foreground" dangerouslySetInnerHTML={{ __html: lesson.content }}/>
        </CardContent>
      </Card>
      
      <Separator className="my-8" />
      
      <div>
        <h2 className="text-3xl font-bold mb-6 flex items-center gap-2">
            <FileQuestion className="text-primary"/>
            تمارين الدرس
        </h2>
        <div className="space-y-8">
            {exercises.map((exercise, index) => {
                const isCurrentExerciseUnlocked = previousExerciseCompleted;
                const submissionForExercise = submissions.find(s => s.exercise_id === exercise.id);
                const hasSucceeded = submissionForExercise && (submissionForExercise.score ?? 0) >= 6;
                
                if (isCurrentExerciseUnlocked) {
                    previousExerciseCompleted = hasSucceeded;
                }

                return (
                    <Card key={exercise.id}>
                        <CardHeader>
                            <CardTitle>تمرين {index + 1}:</CardTitle>
                            {exercise.question && (
                                <div className="prose dark:prose-invert text-lg font-medium pt-2 text-foreground" dangerouslySetInnerHTML={{ __html: exercise.question }} />
                            )}
                             {exercise.question_file_url && (
                                <div className="pt-4">
                                     <Link href={exercise.question_file_url} target="_blank" passHref>
                                        <Button variant="outline">
                                            <Paperclip className="ml-2 h-4 w-4" />
                                            <span>عرض الملف المرفق للسؤال</span>
                                        </Button>
                                    </Link>
                                </div>
                            )}
                        </CardHeader>
                        <CardContent>
                            {isCurrentExerciseUnlocked ? (
                               <ExerciseSubmission exercise={exercise} />
                            ) : (
                                <div className="p-4 bg-muted rounded-md text-muted-foreground">
                                    أكمل التمرين السابق لفتح هذا التمرين.
                                </div>
                            )}
                        </CardContent>
                    </Card>
                )
            })}
             {exercises.length === 0 && (
                <p className="text-muted-foreground text-center py-4">لا توجد تمارين في هذا الدرس بعد.</p>
             )}
        </div>
      </div>
    </div>
  );
}
