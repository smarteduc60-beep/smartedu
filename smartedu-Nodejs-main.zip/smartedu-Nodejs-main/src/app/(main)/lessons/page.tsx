import Link from "next/link";
import Image from "next/image";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getLessons, getSubjectById, getUserById } from "@/lib/mock-data";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { ArrowLeft, Lock } from "lucide-react";
import type { Lesson } from "@/lib/types";

export default function LessonsPage() {
  // Mock current student - in a real app, this would come from session/auth
  const student = getUserById(1);

  // Filter lessons based on the student's context
  const allLessons = getLessons();
  let studentLessons: Lesson[] = [];

  if (student) {
    const teacherCode = student.connected_teacher_code;
    const studentLevel = student.level_id;

    studentLessons = allLessons.filter(lesson => {
      // Include public lessons for the student's level
      const isPublicLessonForLevel = lesson.type === 'public' && lesson.level_id === studentLevel;
      
      // Include private lessons from the student's connected teacher
      const teacher = teacherCode ? getUserById(lesson.author_id) : null;
      const isPrivateLessonFromTeacher = lesson.type === 'private' && teacher?.teacher_code === teacherCode;

      return isPublicLessonForLevel || isPrivateLessonFromTeacher;
    });
  }


  const getLessonImage = (id: number) => {
    const imageName = `lesson${id}`;
    return PlaceHolderImages.find((img) => img.id === imageName);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">قائمة الدروس</h1>
        <p className="text-muted-foreground">
          تصفح جميع الدروس المتاحة لك وابدأ رحلتك التعليمية.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {studentLessons.map((lesson) => {
          const subject = getSubjectById(lesson.subject_id);
          const lessonImage = getLessonImage(lesson.id);
          const author = getUserById(lesson.author_id);
          const isPrivate = lesson.type === 'private';

          return (
            <Card key={lesson.id} className="flex flex-col overflow-hidden">
              <CardHeader className="relative p-0">
                {lessonImage && (
                  <div className="relative aspect-video w-full">
                    <Image
                      src={lessonImage.imageUrl}
                      alt={lesson.title}
                      fill
                      className="object-cover"
                      data-ai-hint={lessonImage.imageHint}
                    />
                     {lesson.is_locked && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <Lock className="h-12 w-12 text-white/80" />
                      </div>
                    )}
                    {isPrivate && (
                        <Badge className="absolute top-2 right-2" variant="default">خاص بالمعلم</Badge>
                    )}
                  </div>
                )}
                <div className="p-6">
                    <div className="flex justify-between items-start">
                        <Badge variant="secondary">{subject?.name}</Badge>
                         <p className="text-xs text-muted-foreground">بواسطة: {author?.name}</p>
                    </div>
                    <CardTitle className="text-xl mt-2">{lesson.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <CardDescription>{lesson.content.substring(0, 100)}...</CardDescription>
              </CardContent>
              <CardFooter>
                <Link href={`/lessons/${lesson.id}`} className="w-full" passHref>
                  <Button className="w-full" disabled={lesson.is_locked}>
                    <span>{lesson.is_locked ? 'الدرس مقفل' : 'ابدأ الدرس'}</span>
                    {!lesson.is_locked && <ArrowLeft className="mr-2 h-4 w-4" />}
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          );
        })}
         {studentLessons.length === 0 && (
            <p className="text-muted-foreground col-span-full text-center">لا توجد دروس متاحة لك حاليًا.</p>
        )}
      </div>
    </div>
  );
}
