# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.

---

## How to Upload to GitHub

Here are the steps to upload your project to a new GitHub repository:

### 1. Create a New Repository on GitHub

1.  Go to [GitHub](https://github.com) and log in.
2.  Click the **+** icon in the top-right corner and select **New repository**.
3.  Give your repository a name (e.g., `smartedu-platform`).
4.  **Important:** Do **not** initialize the repository with a README, .gitignore, or license file, as your project already contains these.
5.  Click **Create repository**.

### 2. Set up Your Local Project

After creating the repository, GitHub will show you a page with some commands. Open a terminal in your project's root directory and run the commands listed under "...or push an existing repository from the command line".

They will look like this (replace the URL with your own repository's URL):

```bash
# Initialize git in your project (if not already done)
git init

# Add all your project files to the staging area
git add .

# Create your first commit
git commit -m "First commit: Initial project setup"

# Set the main branch name (common practice)
git branch -M main

# Link your local project to the remote GitHub repository
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git

# Push your code to GitHub
git push -u origin main
```

That's it! Your project code will now be available on your GitHub repository.
